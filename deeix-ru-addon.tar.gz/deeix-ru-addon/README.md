# deeix-ru: русский язык для DEEIX Chat

Дополнение добавляет локаль `ru-RU` в существующую копию DEEIX Chat. Форк не нужен: апстрим обновляется обычным `git pull`.

## Состав

- `install.sh`: установка, проверка и удаление.
- `patches/ru-locale.patch`: правки 6 существующих файлов веб-приложения.
- `files/`: новые файлы, которые копируются в `apps/web/`:
  - `i18n/ru-messages.ts`: загрузчик `ru-RU`.
  - `i18n/messages/ru-RU/*.json`: переводы по пространствам имён (31 файл).

## Установка

```
/путь/к/deeix-ru/install.sh /путь/к/deeix-chat
cd /путь/к/deeix-chat && pnpm --filter @deeix/web check
```

## Обновление апстрима

Файлы из патча меняются локально, поэтому перед `git pull` дополнение нужно снять:

```
/путь/к/deeix-ru/install.sh --uninstall /путь/к/deeix-chat
git -C /путь/к/deeix-chat pull
/путь/к/deeix-ru/install.sh /путь/к/deeix-chat
cd /путь/к/deeix-chat && pnpm --filter @deeix/web check
```

Проверить, накладывается ли патч на текущую версию, без изменений:

```
/путь/к/deeix-ru/install.sh --check /путь/к/deeix-chat
```

## Конфликты

Если `install.sh` пишет, что патч не накладывается, апстрим изменил один из файлов. Правки в нём небольшие, их можно внести вручную:

| Файл | Что добавляется |
| --- | --- |
| `apps/web/i18n/config.ts` | `"ru-RU"` в `APP_LOCALES` и `APP_LOCALE_LABELS`; распознавание `ru` и `ru-*` в `normalizeAppLocale` и `resolveBrowserLocale` |
| `apps/web/i18n/messages.ts` | импорт `loadRuMessages`; ветка `if (locale === "ru-RU")` в `loadLocaleMessages` |
| `apps/web/i18n/resolve-error-message.ts` | записи `"ru-RU"` в `ERROR_MESSAGES`, `FALLBACK_MESSAGES`, `REQUEST_FIELD_LABELS`, `SETTINGS_FIELD_LABELS`; запасной вариант `?? ...["en-US"]` в двух поисках |
| `apps/web/features/desktop/components/shell-providers.tsx` | импорт `ruDesktopTabs` и запись `"ru-RU"` в `MESSAGES` |
| `apps/web/features/admin/components/shared/date-range-filter.tsx` | `ru` из `date-fns/locale` и выбор локали календаря |
| `apps/web/features/admin/components/shared/date-time-picker.tsx` | то же |

После ручной правки пересоберите патч из текущих файлов (сначала снимите дополнение, как указано выше, и внесите правки в чистый апстрим):

```
git -C /путь/к/deeix-chat diff -- <6 файлов выше> > /путь/к/deeix-ru/patches/ru-locale.patch
```

## Переводы

- Переводы лежат в `files/apps/web/i18n/messages/ru-RU/`. Правьте их здесь, а не в копии репозитория: `install.sh` копирует файлы заново.
- Пустой файл `{}` означает, что пространство имён ещё не переведено. Тогда показывается английский текст.
- Отсутствующие ключи внутри переведённого файла тоже берутся из `en-US`. После обновления апстрима новые строки появятся на английском, пока их не переведут.
- Переведены: `common`, `login`, `desktop-tabs`.
- Множественное число в ICU-строках: для русского нужны формы `one`, `few`, `many` и `other`. Пример: `{count, plural, one {# ошибка} few {# ошибки} many {# ошибок} other {# ошибки}}`.

## Что пока не переведено

- Числа, валюта и токены остаются в `en-US` (`toLocaleString("en-US")`). Это решение, принятое для финансовых значений.
- Тексты ошибок (`errors.json`) и подписи полей в `resolve-error-message.ts` пока на английском.
- Страница входа через OAuth в десктопном приложении (`apps/desktop/src-tauri/src/oauth_loopback.rs`) содержит только английский и китайский тексты.
