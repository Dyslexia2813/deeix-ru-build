# deeix-ru: русский язык для DEEIX Chat

Дополнение добавляет локаль `ru-RU` в существующую установку DEEIX Chat. Форк не нужен: апстрим обновляется как обычно, а русский язык накладывается поверх него.

Сделано под версию `0.4.4-beta.4` (тег `v0.4.4-beta.4`).

## Состав

- `install.sh`: установка, проверка и удаление.
- `patches/ru-locale.patch`: правки 13 существующих файлов (11 во фронтенде, 2 в бэкенде).
- `files/apps/web/i18n/`: новые файлы, копируются в `apps/web/i18n/`:
  - `ru-messages.ts`: загрузчик `ru-RU` (объединяет перевод с английским, чтобы непереведённые строки не показывали сырые ключи);
  - `ru-merge.ts`: общая функция слияния;
  - `ru-error-messages.ts`: тексты ошибок и сообщения проверки полей;
  - `messages/ru-RU/*.json`: переводы по разделам (31 файл).

## Валюта: рубли вместо юаней

Слот «CNY» (валюта отображения) в админке показывается как «Российский рубль (₽)», поле курса — «Курс USD → RUB». Внутренние имена (`CNY`, `usdToCnyRate`) и API не менялись, учёт по-прежнему идёт в USD. Задайте в Биллинге валюту отображения «Российский рубль» и курс (сколько рублей за 1 USD).

Ограничение: платёжные системы (Stripe, EPay) считают сумму по тому же курсу и рассчитаны на юани, поэтому при отображении в рублях принимать через них платежи не следует. Для кодов активации это не важно.
- `github/build-ru.yml`: сборка на GitHub Actions (фронтенд и, при желании, бэкенд).
- `tools/`: проверка и обслуживание переводов (см. ниже).

## Как это устанавливается на VPS

Готовый образ DEEIX Chat уже содержит собранный фронтенд, поэтому русский язык нужно один раз собрать и подключить к контейнеру. Сборка Next.js требует 2–3 ГБ памяти, поэтому её удобно делать на GitHub Actions.

1. Создайте приватный репозиторий (не форк), положите в корень `deeix-ru-addon.tar.gz` и файл `github/build-ru.yml` как `.github/workflows/build.yml`.
2. Вкладка Actions → «Run workflow», тег должен совпадать с запущенной версией (`{"status":"ok","version":"…"}` на `/healthz`).
3. Скачайте артефакт `deeix-ru-out` (сайт) и, по желанию, `deeix-ru-backend` (бинарник сервера, см. ниже).
4. Распакуйте сайт в `/opt/deeix-ru/out` и подключите его файлом `compose.override.yml`:

```yaml
services:
  app:
    volumes:
      - /opt/deeix-ru/out:/app/frontend/out:ro
```

```
cd /opt/deeix-chat/DEEIX-Chat/deploy
docker compose -f docker-compose.sqlite.yml -f /opt/deeix-ru/compose.override.yml up -d
```

Откат: `docker compose -f docker-compose.sqlite.yml up -d` (без второго файла).

### Бэкенд (рекомендуется)

Бэкенд-бинарник нужен для двух вещей: сохранения языка профиля и автоназвания чатов на русском (без исправления название остаётся первыми 16 символами вопроса, если он начинается с заглавной буквы).

Сервер проверяет язык профиля по белому списку `en`, `en-US`, `zh`, `zh-CN`. Без исправления выбор русского не сохраняется в профиле на сервере (при создании пользователя показывается «Invalid language», на другом устройстве интерфейс откроется на английском). Исправление в патче добавляет `ru` и `ru-RU`. Чтобы оно заработало, подключите собранный бинарник:

Распакуйте артефакт `deeix-ru-backend` в `/opt/deeix-ru/` (получится файл `/opt/deeix-ru/deeix-chat`) и дайте ему право на запуск: `chmod +x /opt/deeix-ru/deeix-chat`. Затем добавьте второй том:

```yaml
services:
  app:
    volumes:
      - /opt/deeix-ru/out:/app/frontend/out:ro
      - /opt/deeix-ru/deeix-chat:/app/deeix-chat:ro
```

Бинарник собирается для `linux/amd64`. На другой архитектуре (`uname -m` не `x86_64`) этот шаг пропустите.

## Обновление апстрима

1. Обновите Deeix как обычно (новый образ).
2. Проверьте, что патч накладывается на новую версию: `./install.sh --check /путь/к/deeix-chat` (нужен клон исходников нужного тега).
3. Запустите сборку на GitHub с новым тегом, скачайте артефакты и замените файлы на сервере.

Новые строки, которые апстрим добавит в английские файлы, в русском интерфейсе появятся на английском, пока их не переведут.

## Установка в исходники (если вы собираете сами)

```
./install.sh /путь/к/deeix-chat
cd /путь/к/deeix-chat && pnpm --filter @deeix/web check
./install.sh --uninstall /путь/к/deeix-chat   # снять дополнение перед git pull
```

## Конфликты

Если `install.sh` пишет, что патч не накладывается, апстрим изменил один из файлов. Правки небольшие:

| Файл | Что добавляется |
| --- | --- |
| `apps/web/i18n/config.ts` | `"ru-RU"` в `APP_LOCALES` и `APP_LOCALE_LABELS`; распознавание `ru` и `ru-*` в `normalizeAppLocale` и `resolveBrowserLocale` |
| `apps/web/i18n/messages.ts` | импорт `loadRuMessages`; ветка `if (locale === "ru-RU")` в `loadLocaleMessages` |
| `apps/web/i18n/resolve-error-message.ts` | импорт из `ru-error-messages`; записи `"ru-RU"` в `ERROR_MESSAGES`, `FALLBACK_MESSAGES`, `REQUEST_FIELD_LABELS`, `SETTINGS_FIELD_LABELS`; ветка `ru-RU` в `resolveRequestFieldError`; запасной вариант `?? ...["en-US"]` в двух поисках подписей |
| `apps/web/features/shell/components/sections/project-layout.tsx` | для `ru-RU` новый диалог создаётся с заголовком `New chat`: сервер автоматически называет только чаты с заголовком `New chat` или `新对话`, а русское «Новый чат» не распознаёт, и чаты оставались бы безымянными |
| `apps/web/features/desktop/components/shell-providers.tsx` | импорт `ruDesktopTabs` и запись `"ru-RU"` в `MESSAGES` |
| `apps/web/features/admin/components/shared/date-range-filter.tsx` | `ru` из `date-fns/locale` и выбор локали календаря |
| `apps/web/features/admin/components/shared/date-time-picker.tsx` | то же |
| `apps/web/entities/billing/lib/billing-display.ts` | символ валюты `₽` вместо `¥` в `billingCurrencySymbol` |
| `apps/web/features/admin/components/sections/statistics/statistics-charts.tsx` | `₽` вместо `¥` |
| `apps/web/features/settings/model/subscription-format.ts` | `₽` вместо `¥` в `billingDisplayInputSymbol` и его типе |
| `apps/web/features/chat/components/sections/chat-model-controls.tsx` | подсветка значков параметров чата: список с вариантом «выкл.» (`none`/`off`/`disabled`) горит, пока параметр включён (как переключатели и инструменты), а не только когда значение изменено |
| `backend/internal/infra/persistence/postgres/conversation/repository.go` | исправление апстрима: SQLite `lower()` не понижает регистр кириллицы, из-за чего сгенерированное моделью название не заменяло временное (первые 16 символов), если сообщение начиналось с заглавной буквы. Добавлено сравнение с точным регистром |
| `backend/internal/application/auth/service.go` | `"ru", "ru-RU"` в `case` функции `normalizeLocale` |

После ручной правки пересоберите патч из чистого апстрима с внесёнными правками: `git diff -- <13 файлов выше> > patches/ru-locale.patch`.

## Состояние перевода

- Пользовательский интерфейс переведён полностью: чат, настройки, вход, файлы, недавние, базы знаний, библиотека, ошибки, обучение, диалоги общего доступа, приложение для компьютера.
- Админка переведена в основном: биллинг, уведомления, модерация, настройки диалогов, группы, журналы, статистика, пользователи, инструменты, вход, библиотека.
- Пока на английском: `admin-files`, `admin-upstreams` и часть `admin-models` (пустой файл `{}` или недостающие ключи показываются на английском).
- Числа, валюта и токены остаются в формате `en-US` (`toLocaleString("en-US")`). Это решение для финансовых значений.
- Страница входа через OAuth в приложении для компьютера (`apps/desktop/src-tauri/src/oauth_loopback.rs`) содержит только английский и китайский тексты.

## Инструменты (`tools/`)

- `check-ru.mjs <репозиторий> [файл…]`: сверка ключей, подстановок `{…}`, форм множественного числа и тегов с английским оригиналом.
- `missing-keys.mjs`, `merge-parts.mjs`, `salvage-json.mjs`: выделить непереведённые ключи, собрать перевод из частей, восстановить оборванный JSON.
- `GLOSSARY.ru.md`: словарь терминов и правила стиля. Правьте переводы здесь, в `files/…/ru-RU/`, а не в копии репозитория: `install.sh` копирует файлы заново.
