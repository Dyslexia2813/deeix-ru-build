import enErrors from "@/i18n/messages/en-US/errors.json";
import ruErrors from "@/i18n/messages/ru-RU/errors.json";
import { mergeDeep } from "@/i18n/ru-merge";

/**
 * Russian texts for the error resolver (resolve-error-message.ts), added by the ru-RU add-on.
 * Backend error codes missing from the Russian file fall back to the English text.
 */

export const RU_ERROR_MESSAGES: unknown = mergeDeep(enErrors, ruErrors);

export const RU_FALLBACK_MESSAGE = "Запрос не выполнен. Попробуйте позже.";

export const RU_REQUEST_FIELD_LABELS: Record<string, string> = {
  apiKeys: "Ключи API",
  avatarURL: "URL аватара",
  baseURL: "Базовый URL",
  cbDurationMin: "Длительность отключения",
  cbFailureThreshold: "Порог ошибок",
  cbModelThreshold: "Порог по моделям",
  cbThresholdLogic: "Логика порогов",
  cbWindowMin: "Окно отключения",
  compatible: "Режим совместимости",
  connectTimeoutMS: "Тайм-аут подключения",
  displayName: "Отображаемое имя",
  email: "Эл. почта",
  headersJSON: "Заголовки (JSON)",
  locale: "Язык",
  maskFileID: "Файл маски",
  name: "Название",
  password: "Пароль",
  phone: "Телефон",
  protocolDefaultsJSON: "Параметры протокола по умолчанию (JSON)",
  readTimeoutMS: "Тайм-аут чтения",
  status: "Статус",
  systemPrompt: "Системный промпт",
  streamIdleTimeoutMS: "Тайм-аут простоя потока",
  subscriptionExpiresAt: "Срок действия подписки",
  subscriptionTier: "Тариф подписки",
  timezone: "Часовой пояс",
  username: "Имя пользователя",
};

function charactersWord(count: number): string {
  const lastTwo = count % 100;
  const last = count % 10;
  if (lastTwo >= 11 && lastTwo <= 14) return "символов";
  if (last === 1) return "символ";
  if (last >= 2 && last <= 4) return "символа";
  return "символов";
}

function characters(param: string): string {
  const count = Number(param);
  return Number.isInteger(count) && count >= 0 ? `${count} ${charactersWord(count)}` : `${param} символов`;
}

/** Validation sentence for one request field; `label` is the already localized field name. */
export function ruRequestFieldMessage(rule: string, label: string, param: string): string {
  switch (rule) {
    case "required":
    case "required_without":
      return `Поле «${label}» обязательно для заполнения.`;
    case "min":
      return `Поле «${label}» должно содержать не менее ${characters(param)}.`;
    case "max":
      return `Поле «${label}» должно содержать не более ${characters(param)}.`;
    case "len":
      return `Поле «${label}» должно содержать ровно ${characters(param)}.`;
    case "email":
      return `Поле «${label}» должно содержать корректный адрес эл. почты.`;
    case "url":
      return `Поле «${label}» должно содержать полный URL, например https://api.example.com.`;
    case "oneof":
      return `Поле «${label}» должно принимать одно из значений: ${param}.`;
    default:
      return `Поле «${label}» заполнено неверно.`;
  }
}
