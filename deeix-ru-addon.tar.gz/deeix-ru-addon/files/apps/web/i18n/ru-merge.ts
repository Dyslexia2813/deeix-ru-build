/**
 * Shared helper of the ru-RU add-on: overlays a (possibly partial) Russian message tree onto the
 * English one, so keys that are not translated yet (or that upstream added later) stay in English.
 */

type JsonObject = Record<string, unknown>;

function isPlainObject(value: unknown): value is JsonObject {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** Overlays `override` onto `base` without mutating either; leaves are replaced, objects are merged. */
export function mergeDeep(base: unknown, override: unknown): unknown {
  if (override === undefined) {
    return base;
  }
  if (!isPlainObject(base) || !isPlainObject(override)) {
    return override;
  }
  const merged: JsonObject = { ...base };
  for (const key of Object.keys(override)) {
    merged[key] = mergeDeep(base[key], override[key]);
  }
  return merged;
}
