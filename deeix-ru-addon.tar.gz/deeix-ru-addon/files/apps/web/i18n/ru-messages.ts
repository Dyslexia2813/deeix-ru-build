import type { AppMessages } from "@/i18n/messages";
import { mergeDeep } from "@/i18n/ru-merge";

/**
 * Russian (ru-RU) message loader, added by the deeix-ru add-on.
 *
 * Only the namespace files present in i18n/messages/ru-RU/ are translated.
 * Every key that is missing from them falls back to the English base, so new
 * strings added by upstream updates show in English instead of raw key paths.
 */

const RU_NAMESPACE_LOADERS = {
  desktopSetup: () => import("@/i18n/messages/ru-RU/desktop-setup.json"),
  desktopTabs: () => import("@/i18n/messages/ru-RU/desktop-tabs.json"),
  desktopUpdate: () => import("@/i18n/messages/ru-RU/desktop-update.json"),
  common: () => import("@/i18n/messages/ru-RU/common.json"),
  conversation: () => import("@/i18n/messages/ru-RU/conversation.json"),
  errors: () => import("@/i18n/messages/ru-RU/errors.json"),
  login: () => import("@/i18n/messages/ru-RU/login.json"),
  library: () => import("@/i18n/messages/ru-RU/library.json"),
  uiComponents: () => import("@/i18n/messages/ru-RU/ui-components.json"),
  guide: () => import("@/i18n/messages/ru-RU/guide.json"),
  chat: () => import("@/i18n/messages/ru-RU/chat.json"),
  announcements: () => import("@/i18n/messages/ru-RU/announcements.json"),
  recent: () => import("@/i18n/messages/ru-RU/recent.json"),
  share: () => import("@/i18n/messages/ru-RU/share.json"),
  files: () => import("@/i18n/messages/ru-RU/files.json"),
  knowledgeBases: () => import("@/i18n/messages/ru-RU/knowledge-bases.json"),
  settings: () => import("@/i18n/messages/ru-RU/settings.json"),
  adminAnnouncements: () => import("@/i18n/messages/ru-RU/admin-announcements.json"),
  adminBilling: () => import("@/i18n/messages/ru-RU/admin-billing.json"),
  adminConversation: () => import("@/i18n/messages/ru-RU/admin-conversation.json"),
  adminFiles: () => import("@/i18n/messages/ru-RU/admin-files.json"),
  adminGroups: () => import("@/i18n/messages/ru-RU/admin-groups.json"),
  adminLogin: () => import("@/i18n/messages/ru-RU/admin-login.json"),
  adminLogs: () => import("@/i18n/messages/ru-RU/admin-logs.json"),
  adminModels: () => import("@/i18n/messages/ru-RU/admin-models.json"),
  adminLibrary: () => import("@/i18n/messages/ru-RU/admin-library.json"),
  adminStatistics: () => import("@/i18n/messages/ru-RU/admin-statistics.json"),
  adminTools: () => import("@/i18n/messages/ru-RU/admin-tools.json"),
  adminUpstreams: () => import("@/i18n/messages/ru-RU/admin-upstreams.json"),
  adminUsers: () => import("@/i18n/messages/ru-RU/admin-users.json"),
  adminContentModeration: () => import("@/i18n/messages/ru-RU/admin-content-moderation.json"),
} as const;

export async function loadRuMessages(base: AppMessages): Promise<AppMessages> {
  const entries = await Promise.all(
    Object.entries(RU_NAMESPACE_LOADERS).map(async ([namespace, load]) => [namespace, (await load()).default] as const),
  );
  // Type assertion: mergeDeep is untyped, but its result keeps every key of `base`, which is a full AppMessages.
  return mergeDeep(base, Object.fromEntries(entries)) as AppMessages;
}
