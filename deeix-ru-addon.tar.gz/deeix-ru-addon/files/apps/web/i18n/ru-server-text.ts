// Russian for the texts the DEEIX server writes in Chinese and the site shows as they are:
// the answer's processing trace, model request errors, file processing errors, service status
// lines in the admin panel. The server stores these texts with the message, so they are translated
// at display time, and only when the interface language is Russian.
//
// Rules are tried on each line in order. A line that matches no full rule gets the fragment rules,
// so a line that mixes a known Chinese phrase with names or numbers is still translated in part.

type Rule = [RegExp, string | ((...groups: string[]) => string)];

const CJK_RE = /[　-〿一-鿿＀-￯]/;

// "（a、b）" or "（a、b 等 5 个）" after a message: the names the message is about.
function names(scope: string | undefined): string {
  const value = (scope ?? "").trim();
  if (!value) return "";
  const inner = value.replace(/^（/, "").replace(/）$/, "");
  const more = inner.match(/^(.*?)\s*等\s*(\d+)\s*个$/);
  if (more) return ` (${more[1].split("、").join(", ")} и др., всего ${more[2]})`;
  return ` (${inner.split("、").join(", ")})`;
}

function retrievalReason(reason: string): string {
  switch (reason.trim()) {
    case "检索未命中":
    case "未检索到相关片段":
      return "подходящие фрагменты не найдены";
    case "检索结果低于相似度阈值":
      return "найденное ниже порога сходства";
    case "检索超时":
    case "内容检索超时":
      return "поиск по содержимому не успел";
    case "检索不可用":
    case "内容检索不可用":
      return "поиск по содержимому недоступен";
    case "检索失败":
    case "内容检索失败":
      return "поиск по содержимому не удался";
    case "内容检索已取消":
      return "поиск по содержимому отменён";
    case "检索未完成":
      return "поиск не завершён";
    default:
      return reason;
  }
}

function fallback(label: string): string {
  return label.trim() === "没有可用全文" ? "полного текста нет" : "использован полный текст";
}

const OCR = "(Tesseract OCR|RapidOCR|LLM OCR|OCR)";

const LINE_RULES: Rule[] = [
  // Process summary and request errors.
  [/^请求未完成$/, "Запрос не выполнен"],
  [/^模型不支持图片输入$/, "Модель не принимает изображения"],
  [/^当前模型不支持图片输入，请切换到支持视觉输入的模型，或移除图片后重试。?$/, "Эта модель не принимает изображения. Выберите модель, которая их понимает, или уберите изображение и повторите."],
  [/^模型响应格式不兼容（HTTP (\d+)）$/, (code) => `Ответ модели в несовместимом формате (HTTP ${code})`],
  [/^错误：上游返回成功状态码，但响应格式与当前协议不兼容$/, "Ошибка: провайдер ответил успешно, но формат ответа не подходит к выбранному протоколу"],
  [/^模型请求失败（HTTP (\d+)）$/, (code) => `Запрос к модели не удался (HTTP ${code})`],
  [/^模型请求失败$/, "Запрос к модели не удался"],
  [/^错误：([\s\S]*)$/, (message) => `Ошибка: ${translateLine(message)}`],
  [/^Tips：当前上游可能不支持流式响应.*$/, "Подсказка: провайдер, возможно, не поддерживает потоковый ответ. Администратору стоит выключить «Потоковый вызов изображений» в возможностях модели (image.stream=false) и повторить."],
  [/^upstream service unavailable$/i, "Сервис провайдера недоступен"],
  [/^internal server error$/i, "Внутренняя ошибка сервера"],

  // Trace block titles and stage labels.
  [/^处理$/, "Обработка"],
  [/^模型思考$/, "Размышления модели"],
  [/^工具$/, "Инструменты"],
  [/^请求结果$/, "Результат запроса"],
  [/^上游模型请求触发$/, "Запущено запросом к модели"],
  [/^上下文规划$/, "Планирование контекста"],
  [/^内容检索$/, "Поиск по содержимому"],
  [/^文件上下文$/, "Контекст файлов"],
  [/^上下文压缩$/, "Сжатие контекста"],
  [/^图片附件$/, "Вложенные изображения"],
  [/^Skill 上下文$/, "Контекст навыков"],

  // Tools.
  [/^完成 (\d+) 次工具调用，(\d+) 次失败$/, (total, failed) => `Вызовов инструментов: ${total}, с ошибкой: ${failed}`],
  [/^(\d+) 次工具调用，(\d+) 次失败$/, (total, failed) => `Вызовов инструментов: ${total}, с ошибкой: ${failed}`],
  [/^(\d+) 次工具调用已完成$/, (total) => `Вызовов инструментов выполнено: ${total}`],
  [/^(\d+) 次工具调用进行中$/, (total) => `Вызовов инструментов выполняется: ${total}`],
  [/^返回 (\d+) 张图片$/, (count) => `Возвращено изображений: ${count}`],
  [/^返回 (\d+) 段音频$/, (count) => `Возвращено аудио: ${count}`],
  [/^返回 (\d+) 个资源$/, (count) => `Возвращено ресурсов: ${count}`],
  [/^MCP 工具同步失败$/, "Не удалось синхронизировать инструменты MCP"],

  // Files attached to the message.
  [/^文件已就绪，(.*?)。?$/, (counts) => `Файлы готовы: ${translateLine(counts)}.`],
  [/^部分文件未纳入$/, "Часть файлов не добавлена"],
  [/^(.+?)，文件超出预算或没有可用提取文本，暂未纳入(（.*）)?。?$/, (reason, scope) =>
    `${capitalize(retrievalReason(reason))}: файлы не поместились в лимит или не содержат извлечённого текста и пока не добавлены${names(scope)}.`],
  [/^正在处理附件…?$/, "Обработка вложений…"],
  [/^未命名文件$/, "Файл без названия"],

  // Retrieval.
  [/^正在检索相关内容…?$/, "Поиск подходящих фрагментов…"],
  [/^检索到 (\d+) 段相关内容$/, (count) => `Найдено фрагментов: ${count}`],
  [/^检索已完成，共检索 (\d+) 个文件，命中 (\d+) 个段落。?$/, (files, chunks) => `Поиск завершён: просмотрено файлов — ${files}, найдено фрагментов — ${chunks}.`],
  [/^内容检索未完成，(.+)$/, (label) => `Поиск по содержимому не завершён, ${fallback(label)}`],
  [/^未检索到相关片段，(.+)$/, (label) => `Подходящие фрагменты не найдены, ${fallback(label)}`],
  [/^文件已检索，检索未完成，(.+?)。?$/, (label) => `Файлы просмотрены, поиск не завершён, ${fallback(label)}.`],
  [/^文件已检索，(.+?)，(已改用全文|没有可用全文)。?$/, (miss, label) => `Файлы просмотрены, ${retrievalReason(miss)}, ${fallback(label)}.`],
  [/^(内容检索已取消|内容检索超时|内容检索不可用|内容检索失败|检索未命中|检索结果低于相似度阈值|检索超时|检索不可用|检索失败|未检索到相关片段)$/, (reason) => capitalize(retrievalReason(reason))],
  [/^知识库未检索到相关内容$/, "В базе знаний ничего подходящего не найдено"],
  [/^已检索所选知识库，但没有足够相关的片段。?$/, "Выбранные базы знаний просмотрены, но достаточно близких фрагментов нет."],

  // Images handed to a separate model.
  [/^已通过 (.+) 处理 (\d+) 张图片$/, (processor, count) => `Изображений обработано через ${processor}: ${count}`],
  [/^图片已交由 (.+) 分析，主模型仅接收分析结果。?$/, (processor) => `Изображения проанализировала модель ${processor}, основной модели передан только результат.`],

  // Skills.
  [/^已提供\s*(\d+)\s*个\s*Skill\s*上下文$/, (count) => `Навыков передано: ${count}`],
  [/^本轮已加载\s*Skill[：:]\s*(.*?)[。.]?\s*包含\s*SKILL\.md\s*内容[，,]\s*相关时使用[。.]?$/, (list) =>
    `Загружены для этого ответа: ${list.split("、").map((name) => name.trim()).filter(Boolean).join(", ")}. Текст SKILL.md используется, когда он уместен.`],

  // Context compaction and the context plan.
  [/^对话已压缩并生成滚动摘要。?$/, "Диалог сжат, составлена сводка."],
  [/^压缩区间：第 (\d+)-(\d+) 轮。?$/, (from, to) => `Сжаты ходы ${from}–${to}.`],
  [/^Tokens 缩减：(\d+) → (\d+)。?$/, (before, after) => `Токенов: ${before} → ${after}.`],
  [/^已压缩第 (\d+)-(\d+) 轮上下文$/, (from, to) => `Сжат контекст ходов ${from}–${to}`],
  [/^正在压缩上下文$/, "Сжатие контекста…"],
  [/^上下文压缩未完成$/, "Сжатие контекста не завершено"],
  [/^续接发送 (\d+) 条消息$/, (count) => `Отправлено продолжением сообщений: ${count}`],
  [/^准备 (\d+) tokens 上下文$/, (count) => `Подготовлено токенов контекста: ${count}`],
  [/^上下文摘要 (\d+)-(\d+)$/, (from, to) => `Сводка контекста ${from}–${to}`],
  [/^上下文摘要$/, "Сводка контекста"],
  [/^对话文件$/, "Файлы диалога"],
  [/^系统策略$/, "Системные правила"],
  [/^历史对话$/, "История диалога"],
  [/^历史证据$/, "Сведения из истории"],
  [/^本轮动态上下文$/, "Контекст этого хода"],
  [/^工具使用规则$/, "Правила вызова инструментов"],
  [/^标题$/, "Название"],
  [/^标签$/, "Метки"],
  [/^新对话$/, "Новый чат"],

  // Files: extraction and OCR.
  [/^文件处理失败，请稍后重试。?$/, "Не удалось обработать файл, повторите позже."],
  [/^文件处理队列繁忙，请稍后重试。?$/, "Очередь обработки файлов занята, повторите позже."],
  [/^文件处理队列暂时不可用，请稍后重试。?$/, "Очередь обработки файлов временно недоступна, повторите позже."],
  [/^文件提取超时，请稍后重试，或缩小文件后重试。?$/, "Извлечение текста не успело. Повторите позже или уменьшите файл."],
  [/^当前文件类型不支持处理。?$/, "Этот тип файла не обрабатывается."],
  [/^文件已完成文本提取，但向量化失败。?$/, "Текст из файла извлечён, но индексирование не удалось."],
  [new RegExp(`^PDF 未提取到可读文本，且当前未启用 ${OCR}。.*$`), (engine) => `В PDF нет читаемого текста, а ${engine} не включён. Возможно, это скан, PDF из изображений или зашифрованный PDF.`],
  [new RegExp(`^PDF 未提取到可读文本，且 ${OCR} 识别失败。.*$`), (engine) => `В PDF нет читаемого текста, и ${engine} не смог его распознать. Возможно, это скан, PDF из изображений или зашифрованный PDF.`],
  [new RegExp(`^${OCR} 未识别出可读文本。.*$`), (engine) => `${engine} не распознал читаемый текст. Возможно, страницы пустые, качество изображения слишком низкое или содержимое не распознаётся.`],
  [new RegExp(`^${OCR} 服务无法处理该 PDF。.*$`), (engine) => `Сервис ${engine} не смог обработать этот PDF. Файл может быть повреждён, зашифрован или слишком сложен для этого сервиса.`],
  [new RegExp(`^${OCR} 服务返回格式不符合当前页级协议.*$`), (engine) => `Сервис ${engine} вернул ответ в неожиданном формате, результаты по страницам не объединить.`],
  [new RegExp(`^${OCR} 服务鉴权失败.*$`), (engine) => `Сервис ${engine} не принял ключ доступа, проверьте его в настройках.`],
  [new RegExp(`^${OCR} 服务拒绝访问.*$`), (engine) => `Сервис ${engine} отказал в доступе, проверьте настройки доступа на его стороне.`],
  [new RegExp(`^${OCR} 服务请求失败，请稍后重试。?$`), (engine) => `Запрос к сервису ${engine} не удался, повторите позже.`],
  [new RegExp(`^当前 ${OCR} 服务不可用，无法从扫描件中提取文本。?$`), (engine) => `Сервис ${engine} недоступен, текст из скана не извлечь.`],
  [/^Tika 未提取到可读文本。该 PDF.*$/, "Tika не извлекла читаемый текст. Возможно, это скан, PDF из изображений, зашифрованный PDF или текст в нём нельзя скопировать."],
  [/^Tika 未提取到可读文本。.*$/, "Tika не извлекла читаемый текст. Файл может состоять в основном из изображений, пустых страниц или не содержать копируемого текста."],
  [/^Tika 无法处理该文件。.*$/, "Tika не смогла обработать файл. Он может быть повреждён, зашифрован или в неподдерживаемом формате."],
  [/^Tika 服务鉴权失败.*$/, "Сервис Tika не принял токен, проверьте его в настройках."],
  [/^Tika 服务拒绝访问.*$/, "Сервис Tika отказал в доступе, проверьте настройки доступа на его стороне."],
  [/^Tika 不支持当前文件类型或 MIME 类型。?$/, "Tika не поддерживает этот тип файла (MIME)."],
  [/^Tika 服务请求失败，请稍后重试。?$/, "Запрос к сервису Tika не удался, повторите позже."],
  [/^PDF 未提取到可读文本。.*$/, "В PDF нет читаемого текста. Возможно, это скан, PDF из изображений, зашифрованный PDF или текст в нём нельзя скопировать."],
  [/^PDF 未提取到可读文本，且当前 OCR 服务不可用。.*$/, "В PDF нет читаемого текста, а сервис OCR недоступен. Возможно, это скан, PDF из изображений или зашифрованный PDF."],
  [/^PDF 解析失败.*$/, "Не удалось разобрать PDF. Проверьте, не повреждён ли он, не зашифрован ли и нет ли ошибок в формате."],
  [/^无法提取文本.*$/, "Не удалось извлечь текст. Проверьте, не повреждён ли файл, не зашифрован ли и не состоит ли в основном из изображений."],
  [/^当前 OCR 服务不可用，无法从扫描件中提取文本。?$/, "Сервис OCR недоступен, текст из скана не извлечь."],

  // Files: indexing (embeddings).
  [/^向量化失败，请稍后重试。?$/, "Индексирование не удалось, повторите позже."],
  [/^向量化服务暂时不可用，请稍后重试。?$/, "Сервис индексирования временно недоступен, повторите позже."],
  [/^向量化服务尚未配置。?$/, "Сервис индексирования не настроен."],
  [/^向量化超时，请稍后重试。?$/, "Индексирование не успело, повторите позже."],
  [/^向量化已取消。?$/, "Индексирование отменено."],
  [/^无法读取文件提取文本。?$/, "Не удалось прочитать извлечённый текст файла."],
  [/^文件没有可用于向量化的内容。?$/, "В файле нет содержимого для индексирования."],
  [/^向量化配置已变更，请重新提交任务。?$/, "Настройки индексирования изменились, запустите задачу заново."],
  [/^图片过大，缩放后仍超过向量化上限。?$/, "Изображение слишком большое: даже после уменьшения оно превышает лимит индексирования."],
  [/^图片格式不受当前向量化服务支持。?$/, "Сервис индексирования не поддерживает этот формат изображения."],
  [/^当前向量化协议不支持该输入类型。?$/, "Протокол индексирования не поддерживает такой тип данных."],
  [/^向量化任务超时或被中断，请重试。?$/, "Задача индексирования прервана или не успела, повторите."],
  [/^Embedding 服务未启用$/, "Сервис эмбеддингов выключен"],
  [/^Embedding 服务地址未配置$/, "Не указан адрес сервиса эмбеддингов"],
  [/^Embedding 请求模型未配置$/, "Не указана модель эмбеддингов"],
  [/^Embedding 服务连接失败.*$/, "Не удалось подключиться к сервису эмбеддингов, проверьте настройки и работает ли он"],
  [/^连接正常$/, "Подключение в порядке"],

  // Admin panel: document services status.
  [/^无法读取 (Tika|RapidOCR) 容器状态。?$/, (name) => `Не удалось прочитать состояние контейнера ${name}.`],
  [/^(Tika|RapidOCR) 服务启动超时，请检查容器状态。?$/, (name) => `Сервис ${name} не запустился вовремя, проверьте контейнер.`],
  [/^无法连接 (Tika|RapidOCR|Docling|Tesseract OCR|MinerU) 服务，请检查服务地址和认证配置。?$/, (name) => `Не удалось подключиться к ${name}, проверьте адрес сервиса и доступ.`],
  [/^(Tika|RapidOCR) 容器当前未运行。?$/, (name) => `Контейнер ${name} не запущен.`],
  [/^请先填写 (Tika|RapidOCR|Docling|Tesseract OCR|MinerU) 服务地址。?$/, (name) => `Сначала укажите адрес сервиса ${name}.`],
  [/^已连接到外部 (Tika|RapidOCR|Docling|Tesseract OCR|MinerU) 服务。?$/, (name) => `Подключено к внешнему сервису ${name}.`],
  [/^当前环境未检测到 docker 命令，无法托管 (Tika|RapidOCR)。?$/, (name) => `Команда docker не найдена, запустить ${name} в контейнере нельзя.`],
  [/^(Tika|RapidOCR) 容器尚未启动。?$/, (name) => `Контейнер ${name} ещё не запущен.`],
  [/^(Tika|RapidOCR) 容器运行正常。?$/, (name) => `Контейнер ${name} работает.`],
  [/^服务地址为空。?$/, "Адрес сервиса не указан."],
  [/^服务地址格式不正确。?$/, "Адрес сервиса указан неверно."],
  [/^服务已响应: (\d+)$/, (code) => `Сервис ответил: ${code}`],
  [/^服务响应异常: (\d+)$/, (code) => `Сервис ответил с ошибкой: ${code}`],
  [/^未检测到 MinerU 自部署 API 或云端批处理接口。?$/, "Не найдены ни свой API MinerU, ни облачный пакетный интерфейс."],
];

// Phrases replaced inside a line that no full rule matched.
const FRAGMENT_RULES: Rule[] = [
  [/未纳入 (\d+) 个文件/g, (count) => `не добавлено файлов: ${count}`],
  [/(?:已纳入|纳入) (\d+) 个文件/g, (count) => `добавлено файлов: ${count}`],
  [/结果：/g, "результат: "],
  [/执行失败/g, "выполнить не удалось"],
  // Tool status words, only where they stand alone between separators.
  [/(^|[；;，,]\s*)已完成(?=\s*(?:$|[；;，,]))/g, (lead) => `${lead}выполнено`],
  [/(^|[；;，,]\s*)已复用(?=\s*(?:$|[；;，,]))/g, (lead) => `${lead}использовано повторно`],
  [/(^|[；;，,]\s*)进行中(?=\s*(?:$|[；;，,]))/g, (lead) => `${lead}выполняется`],
  [/(^|[；;，,]\s*)失败(?=\s*(?:$|[；;，,]))/g, (lead) => `${lead}ошибка`],
  [/错误：/g, "Ошибка: "],
  [/(\d+)ms/g, (ms) => `${ms} мс`],
  [/^(.+?)触发$/g, (what) => `Запущено: ${what}`],
  [/；\s*/g, "; "],
  [/，\s*/g, ", "],
  [/：\s*/g, ": "],
  [/。$/g, "."],
  [/。\s*/g, ". "],
  [/、/g, ", "],
  [/（/g, " ("],
  [/）/g, ")"],
];

function capitalize(value: string): string {
  return value ? value.charAt(0).toUpperCase() + value.slice(1) : value;
}

function applyRule(rule: Rule, text: string): string | null {
  const [pattern, replacement] = rule;
  pattern.lastIndex = 0;
  const match = text.match(pattern);
  if (!match) return null;
  return typeof replacement === "string" ? replacement : replacement(...match.slice(1));
}

function translateLine(line: string): string {
  const prefix = line.match(/^\s*(?:[-*]\s+)?/)?.[0] ?? "";
  const body = line.slice(prefix.length).trim();
  if (!body || !CJK_RE.test(body) && !/^(upstream service unavailable|internal server error)$/i.test(body)) {
    return line;
  }
  // "**Label**：detail" written by formatTraceStep.
  const step = body.match(/^\*\*(.+?)\*\*：\s*([\s\S]*)$/);
  if (step) {
    return `${prefix}**${translateLine(step[1])}**: ${translateLine(step[2])}`;
  }
  for (const rule of LINE_RULES) {
    const translated = applyRule(rule, body);
    if (translated !== null) return prefix + translated;
  }
  let result = body;
  for (const [pattern, replacement] of FRAGMENT_RULES) {
    result = typeof replacement === "string"
      ? result.replace(pattern, replacement)
      : result.replace(pattern, (...args: unknown[]) => replacement(...args.slice(1, -2).map(String)));
  }
  return prefix + result.trim();
}

/** Translates the server's Chinese text into Russian. Text without Chinese is returned as it is. */
export function translateServerTextRu(text: string): string {
  if (!text) return text;
  return text.split("\n").map(translateLine).join("\n");
}

function interfaceIsRussian(): boolean {
  if (typeof document === "undefined") return false;
  return document.documentElement.lang.toLowerCase().startsWith("ru");
}

/** Shows a server text in the interface language: Russian when the interface is Russian, unchanged otherwise. */
export function localizeServerText(text: string): string;
export function localizeServerText(text: string | undefined): string | undefined;
export function localizeServerText(text: string | null | undefined): string | null | undefined;
export function localizeServerText(text: string | null | undefined): string | null | undefined {
  if (!text || !interfaceIsRussian()) return text;
  return translateServerTextRu(text);
}
