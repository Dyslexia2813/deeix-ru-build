"use client";

import { Download, FileSpreadsheet, FileText } from "lucide-react";
import type * as React from "react";

import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

export type TableExportItem = {
  key: string;
  label: string;
  kind: "spreadsheet" | "text";
  onSelect: () => void;
};

type TableExportMenuProps = {
  label: string;
  items: readonly TableExportItem[];
  disabled?: boolean;
  className?: string;
  iconClassName?: string;
};

// Download menu for tables in answers (deeix-ru add-on): Excel first, then the text formats.
export function TableExportMenu({ label, items, disabled, className, iconClassName }: TableExportMenuProps) {
  return (
    <DropdownMenu modal={false}>
      <DropdownMenuTrigger asChild disabled={disabled}>
        <button
          type="button"
          aria-label={label}
          title={label}
          className={cn(
            "cursor-pointer text-muted-foreground transition-colors hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50",
            className,
          )}
        >
          <Download className={cn("size-3.5", iconClassName)} strokeWidth={1.8} />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-[10rem]">
        {items.map((item) => (
          <DropdownMenuItem key={item.key} onSelect={item.onSelect}>
            <TableExportIcon kind={item.kind} />
            {item.label}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function TableExportIcon({ kind }: { kind: TableExportItem["kind"] }): React.ReactElement {
  return kind === "spreadsheet" ? <FileSpreadsheet strokeWidth={1.8} /> : <FileText strokeWidth={1.8} />;
}
