"use client";

// Exports chat messages as a Word (.docx) document. The rendered message HTML is converted to
// WordprocessingML directly, so headings, lists, tables, code blocks, links, formulas (as TeX
// text) and images survive. Part of the deeix-ru add-on; it uses no extra dependency.

import { downloadBlob } from "@/shared/lib/export-download";
import { OMIT_SELECTOR } from "@/shared/lib/print-pdf";
import { createZip } from "@/shared/lib/zip-writer";

type Locale = string | undefined;

export type DocxExportMessage = {
  role: "user" | "assistant";
  element: HTMLElement;
};

export type DocxExportOptions = {
  /** Document title; also the base of the file name. */
  title: string;
  /** Show a "You" / "Assistant" label before every message. */
  roleLabels?: { user: string; assistant: string };
  /** Print the title as a heading at the top of the document. */
  showTitle?: boolean;
};

export function docxExportLabel(locale: Locale): string {
  if (locale?.toLowerCase().startsWith("ru")) {
    return "Экспорт в Word (DOCX)";
  }
  if (locale?.toLowerCase().startsWith("zh")) {
    return "导出为 Word (DOCX)";
  }
  return "Export Word (DOCX)";
}

export function docxRoleLabels(locale: Locale): { user: string; assistant: string } {
  if (locale?.toLowerCase().startsWith("ru")) {
    return { user: "Вы", assistant: "Ассистент" };
  }
  if (locale?.toLowerCase().startsWith("zh")) {
    return { user: "你", assistant: "助手" };
  }
  return { user: "You", assistant: "Assistant" };
}

const EXTRA_OMIT_SELECTOR = [
  "[data-streamdown='code-block-header']",
  "[data-streamdown='table-download-actions']",
  "[data-streamdown='link-safety-modal']",
  "[data-streamdown='image-overlay']",
  "[data-streamdown='mermaid-fullscreen']",
  "[data-streamdown='table-fullscreen']",
  ".sr-only",
  "button",
  "script",
  "style",
  "noscript",
  "template",
  "select",
  "textarea",
].join(",");
const SKIP_SELECTOR = `${OMIT_SELECTOR},${EXTRA_OMIT_SELECTOR}`;

const MAX_IMAGE_EMU = 5_486_400; // 6 inches
const MAX_IMAGE_HEIGHT_EMU = 7_315_200; // 8 inches
const EMU_PER_PX = 9525;
const MAX_IMAGE_SIDE_PX = 1800;
const LIST_INDENT = 540;
const TEXT_WIDTH_DXA = 9638; // A4 with 2 cm margins

// ---------- XML helpers ----------

function esc(value: string): string {
  return value
    // Characters that are not allowed in XML 1.0.
    // biome-ignore lint/suspicious/noControlCharactersInRegex: stripping invalid XML characters
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F￾￿]/g, "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

type RunStyle = {
  b?: boolean;
  i?: boolean;
  s?: boolean;
  code?: boolean;
  sup?: boolean;
  sub?: boolean;
  link?: boolean;
  u?: boolean;
  /** Values taken from the screen; set only where they differ from the document defaults. */
  font?: string;
  /** Font size in half-points. */
  size?: number;
  /** Text color, hex without "#". */
  color?: string;
  /** Text background, hex without "#". */
  fill?: string;
};

function fontsXml(font: string): string {
  const name = esc(font);
  return `<w:rFonts w:ascii="${name}" w:hAnsi="${name}" w:cs="${name}" w:eastAsia="${name}"/>`;
}

function runProps(style: RunStyle): string {
  // Child order follows the WordprocessingML schema (rStyle, rFonts, b, i, strike, color, sz, u, shd, vertAlign).
  let out = "";
  if (style.link) {
    out += '<w:rStyle w:val="Hyperlink"/>';
  }
  if (style.code) {
    out += fontsXml("Consolas");
  } else if (style.font) {
    out += fontsXml(style.font);
  }
  if (style.b) {
    out += "<w:b/><w:bCs/>";
  }
  if (style.i) {
    out += "<w:i/><w:iCs/>";
  }
  if (style.s) {
    out += "<w:strike/>";
  }
  if (style.color) {
    out += `<w:color w:val="${style.color}"/>`;
  }
  if (style.code) {
    out += '<w:sz w:val="20"/><w:szCs w:val="20"/>';
  } else if (style.size) {
    out += `<w:sz w:val="${style.size}"/><w:szCs w:val="${style.size}"/>`;
  }
  if (style.u) {
    out += '<w:u w:val="single"/>';
  }
  if (style.code) {
    out += `<w:shd w:val="clear" w:color="auto" w:fill="${style.fill ?? "EEF0F2"}"/>`;
  } else if (style.fill) {
    out += `<w:shd w:val="clear" w:color="auto" w:fill="${style.fill}"/>`;
  }
  if (style.sup) {
    out += '<w:vertAlign w:val="superscript"/>';
  } else if (style.sub) {
    out += '<w:vertAlign w:val="subscript"/>';
  }
  return out ? `<w:rPr>${out}</w:rPr>` : "";
}

function textRun(text: string, style: RunStyle): string {
  if (!text) {
    return "";
  }
  const parts = text.split("\t");
  const inner = parts
    .map((part) => (part ? `<w:t xml:space="preserve">${esc(part)}</w:t>` : ""))
    .join("<w:tab/>");
  return `<w:r>${runProps(style)}${inner}</w:r>`;
}

// ---------- conversion context ----------

type Relationship = { id: string; type: string; target: string; external: boolean };
type MediaFile = { name: string; data: Uint8Array };

type Context = {
  rels: Relationship[];
  media: MediaFile[];
  orderedLists: number;
  numbering: string[];
  nextRel: number;
  nextDrawing: number;
  base: ScreenBase;
};

type Box = { fill?: string; border?: string };

type BlockState = {
  /** Depth of the current list (0 = outside lists). */
  level: number;
  /** List item that still has to receive its bullet / number. */
  item?: { numId: number; ilvl: number; used: boolean };
  quote: number;
  style: RunStyle;
  align?: "left" | "center" | "right";
  /** Background and frame of the nearest block that has them on screen (cards and callouts). */
  box?: Box;
};

// ---------- styles taken from the screen ----------

/** Document defaults: the look of the main answer text on screen. */
type ScreenBase = {
  font: string;
  /** Half-points. */
  size: number;
  /** Hex without "#". */
  color: string;
  weight: number;
  /** Dark theme: colors are left out, the Word page is white. */
  dark: boolean;
};

const DEFAULT_BASE: ScreenBase = { font: "Calibri", size: 22, color: "000000", weight: 400, dark: false };

// Fonts that Word has on practically every computer. The first of them in a CSS font stack is used,
// so the file looks the same on the reader's computer as on screen.
const WORD_FONTS = [
  "Segoe UI", "Arial", "Calibri", "Cambria", "Times New Roman", "Georgia", "Palatino Linotype", "Book Antiqua",
  "Garamond", "Consolas", "Courier New", "Lucida Console", "Verdana", "Tahoma", "Trebuchet MS", "Century Gothic",
  "Candara", "Constantia", "Corbel", "Aptos", "Microsoft YaHei", "SimSun", "SimHei",
];
const WORD_FONT_BY_KEY = new Map(WORD_FONTS.map((name) => [name.toLowerCase(), name]));
const GENERIC_FONTS = new Set([
  "ui-sans-serif", "system-ui", "-apple-system", "blinkmacsystemfont", "sans-serif", "serif", "ui-serif",
  "monospace", "ui-monospace", "cursive", "fantasy", "ui-rounded", "math", "emoji", "fangsong", "inherit", "initial",
]);

const fontCache = new Map<string, string>();

/** Picks the Word font for a CSS font-family value. */
function wordFont(stack: string): string {
  const cached = fontCache.get(stack);
  if (cached) {
    return cached;
  }
  const names = stack
    .split(",")
    .map((name) => name.trim().replace(/^["']|["']$/g, "").trim())
    .filter(Boolean);
  const keys = names.map((name) => name.toLowerCase());
  let font =
    keys.map((key) => WORD_FONT_BY_KEY.get(key)).find((name) => name !== undefined) ??
    names.find((name, index) => {
      const key = keys[index];
      // next/font names look like "__Geist_a1b2c3"; emoji fonts carry no letters.
      return !GENERIC_FONTS.has(key) && !name.startsWith("__") && !/emoji|symbol/.test(key);
    });
  if (!font) {
    if (keys.some((key) => key === "monospace" || key === "ui-monospace")) {
      font = "Consolas";
    } else if (keys.some((key) => key === "serif" || key === "ui-serif")) {
      font = "Times New Roman";
    } else {
      font = "Arial";
    }
  }
  fontCache.set(stack, font);
  return font;
}

let colorCanvas: CanvasRenderingContext2D | null | undefined;
const colorCache = new Map<string, string | null>();

/** Converts any CSS color (rgb, oklch, color-mix...) to hex over a white page; null when transparent. */
function cssColorHex(value: string): string | null {
  if (!value || value === "transparent" || value === "rgba(0, 0, 0, 0)") {
    return null;
  }
  const cached = colorCache.get(value);
  if (cached !== undefined) {
    return cached;
  }
  if (colorCanvas === undefined) {
    const canvas = document.createElement("canvas");
    canvas.width = 1;
    canvas.height = 1;
    colorCanvas = canvas.getContext("2d", { willReadFrequently: true });
  }
  let result: string | null = null;
  if (colorCanvas) {
    colorCanvas.clearRect(0, 0, 1, 1);
    colorCanvas.fillStyle = "#000000";
    colorCanvas.fillStyle = value;
    colorCanvas.fillRect(0, 0, 1, 1);
    const [r, g, b, a] = colorCanvas.getImageData(0, 0, 1, 1).data;
    if (a >= 10) {
      const alpha = a / 255;
      const blend = (channel: number) => Math.round(channel * alpha + 255 * (1 - alpha));
      result = [blend(r), blend(g), blend(b)].map((channel) => channel.toString(16).padStart(2, "0")).join("").toUpperCase();
    }
  }
  colorCache.set(value, result);
  return result;
}

function halfPoints(fontSize: string): number {
  const px = Number.parseFloat(fontSize);
  // 1 CSS px = 0.75 pt = 1.5 half-points.
  return Number.isFinite(px) && px > 0 ? Math.min(400, Math.max(2, Math.round(px * 1.5))) : 0;
}

function screenBase(element: HTMLElement | undefined): ScreenBase {
  if (!element) {
    return DEFAULT_BASE;
  }
  const cs = window.getComputedStyle(element);
  return {
    font: wordFont(cs.fontFamily),
    size: halfPoints(cs.fontSize) || DEFAULT_BASE.size,
    color: cssColorHex(cs.color) ?? DEFAULT_BASE.color,
    weight: Number.parseInt(cs.fontWeight, 10) || 400,
    dark: document.documentElement.classList.contains("dark"),
  };
}

/** Own background of an element, unless it is white or the page itself. */
function ownFill(cs: CSSStyleDeclaration, ctx: Context): string | undefined {
  if (ctx.base.dark) {
    return undefined;
  }
  const fill = cssColorHex(cs.backgroundColor);
  return fill && fill !== "FFFFFF" ? fill : undefined;
}

/** Run style of an element as it looks on screen, on top of the style it inherits. */
function screenStyle(element: Element, style: RunStyle, ctx: Context, inline: boolean): RunStyle {
  if (!(element instanceof HTMLElement)) {
    return style;
  }
  const cs = window.getComputedStyle(element);
  const next: RunStyle = { ...style };
  const font = wordFont(cs.fontFamily);
  next.font = font !== ctx.base.font ? font : undefined;
  const size = halfPoints(cs.fontSize);
  next.size = size && size !== ctx.base.size ? size : undefined;
  const weight = Number.parseInt(cs.fontWeight, 10) || 400;
  next.b = weight >= Math.max(600, ctx.base.weight + 100);
  next.i = cs.fontStyle === "italic" || cs.fontStyle.startsWith("oblique");
  // Text decorations are not inherited in CSS, so they are collected on the way down.
  const decoration = cs.textDecorationLine || "";
  if (decoration.includes("underline")) {
    next.u = true;
  }
  if (decoration.includes("line-through")) {
    next.s = true;
  }
  if (!ctx.base.dark) {
    const color = cssColorHex(cs.color);
    next.color = color && color !== ctx.base.color ? color : undefined;
    if (inline) {
      next.fill = ownFill(cs, ctx) ?? style.fill;
    }
  }
  return next;
}

function borderColor(cs: CSSStyleDeclaration): string | undefined {
  const sides = ["Top", "Right", "Bottom", "Left"] as const;
  for (const side of sides) {
    const width = Number.parseFloat(cs.getPropertyValue(`border-${side.toLowerCase()}-width`));
    const lineStyle = cs.getPropertyValue(`border-${side.toLowerCase()}-style`);
    if (!(width >= 0.5) || lineStyle === "none" || lineStyle === "hidden") {
      return undefined;
    }
  }
  return cssColorHex(cs.borderTopColor) ?? undefined;
}

/** State for a block element: its look on screen, alignment and card frame. */
function blockState(element: Element, state: BlockState, ctx: Context): BlockState {
  if (!(element instanceof HTMLElement)) {
    return state;
  }
  const next: BlockState = { ...state, style: screenStyle(element, state.style, ctx, false) };
  const cs = window.getComputedStyle(element);
  const align = cs.textAlign;
  if (align === "center") {
    next.align = "center";
  } else if (align === "right" || align === "end") {
    next.align = "right";
  } else if (align === "left" || align === "start") {
    next.align = undefined;
  }
  if (!ctx.base.dark) {
    const fill = ownFill(cs, ctx);
    const border = borderColor(cs);
    if (fill || border) {
      next.box = { fill, border };
    }
  }
  return next;
}

function addRel(ctx: Context, type: string, target: string, external: boolean): string {
  const id = `rId${ctx.nextRel}`;
  ctx.nextRel += 1;
  ctx.rels.push({ id, type, target, external });
  return id;
}

const REL_IMAGE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/image";
const REL_LINK = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink";

// ---------- DOM helpers ----------

function isSkipped(element: Element): boolean {
  if (element.matches(SKIP_SELECTOR)) {
    return true;
  }
  if (element instanceof HTMLElement && element.hidden) {
    return true;
  }
  if (element instanceof HTMLElement || element instanceof SVGElement) {
    return window.getComputedStyle(element).display === "none";
  }
  return false;
}

const INLINE_TAGS = new Set([
  "a", "abbr", "b", "bdi", "bdo", "br", "cite", "code", "data", "del", "dfn", "em", "i", "img", "input", "ins",
  "kbd", "mark", "q", "s", "samp", "small", "span", "strike", "strong", "sub", "sup", "time", "tt", "u", "var",
  "wbr", "label", "canvas",
]);

function tagOf(node: Node): string {
  return node instanceof Element ? node.tagName.toLowerCase() : "";
}

function isKatex(element: Element): boolean {
  return element.classList.contains("katex") || element.classList.contains("katex-display");
}

function katexSource(element: Element): string {
  const annotation = element.querySelector("annotation[encoding='application/x-tex']");
  return annotation?.textContent?.trim() ?? element.textContent?.trim() ?? "";
}

function isBlockNode(node: Node): boolean {
  if (!(node instanceof Element)) {
    return false;
  }
  if (isKatex(node)) {
    return node.classList.contains("katex-display");
  }
  const tag = node.tagName.toLowerCase();
  if (tag === "svg") {
    return true;
  }
  return !INLINE_TAGS.has(tag);
}

// ---------- images ----------

type RasterImage = { data: Uint8Array; width: number; height: number };

function loadImage(src: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const image = new Image();
    image.crossOrigin = "anonymous";
    image.onload = () => resolve(image);
    image.onerror = () => resolve(null);
    image.src = src;
  });
}

function canvasToPNG(canvas: HTMLCanvasElement): Promise<Uint8Array | null> {
  return new Promise((resolve) => {
    try {
      canvas.toBlob((blob) => {
        if (!blob) {
          resolve(null);
          return;
        }
        blob.arrayBuffer().then((buffer) => resolve(new Uint8Array(buffer)), () => resolve(null));
      }, "image/png");
    } catch {
      resolve(null);
    }
  });
}

async function rasterize(
  source: CanvasImageSource,
  width: number,
  height: number,
): Promise<RasterImage | null> {
  if (width <= 0 || height <= 0) {
    return null;
  }
  const scale = Math.min(1, MAX_IMAGE_SIDE_PX / Math.max(width, height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(width * scale));
  canvas.height = Math.max(1, Math.round(height * scale));
  const context = canvas.getContext("2d");
  if (!context) {
    return null;
  }
  try {
    context.fillStyle = "#ffffff";
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.drawImage(source, 0, 0, canvas.width, canvas.height);
  } catch {
    return null;
  }
  const data = await canvasToPNG(canvas);
  return data ? { data, width, height } : null;
}

async function imageFromElement(element: HTMLImageElement): Promise<RasterImage | null> {
  const src = element.currentSrc || element.src;
  if (!src) {
    return null;
  }
  let loaded: HTMLImageElement | null = null;
  try {
    const response = await fetch(src, { credentials: "include" });
    if (response.ok) {
      const blob = await response.blob();
      const objectURL = URL.createObjectURL(blob);
      try {
        loaded = await loadImage(objectURL);
        if (loaded) {
          const width = loaded.naturalWidth || element.naturalWidth || 600;
          const height = loaded.naturalHeight || element.naturalHeight || 400;
          const result = await rasterize(loaded, width, height);
          if (result) {
            return result;
          }
        }
      } finally {
        URL.revokeObjectURL(objectURL);
      }
    }
  } catch {
    // Fall back to the image element that is already on the page.
  }
  if (element.complete && element.naturalWidth > 0) {
    return rasterize(element, element.naturalWidth, element.naturalHeight);
  }
  return null;
}

async function imageFromSVG(element: SVGElement): Promise<RasterImage | null> {
  const rect = element.getBoundingClientRect();
  if (rect.width < 60 || rect.height < 40) {
    return null;
  }
  const clone = element.cloneNode(true);
  if (!(clone instanceof SVGElement)) {
    return null;
  }
  clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  clone.setAttribute("width", String(Math.round(rect.width)));
  clone.setAttribute("height", String(Math.round(rect.height)));
  const markup = new XMLSerializer().serializeToString(clone);
  const objectURL = URL.createObjectURL(new Blob([markup], { type: "image/svg+xml;charset=utf-8" }));
  try {
    const loaded = await loadImage(objectURL);
    if (!loaded) {
      return null;
    }
    return await rasterize(loaded, Math.round(rect.width), Math.round(rect.height));
  } finally {
    URL.revokeObjectURL(objectURL);
  }
}

async function imageFromCanvas(element: HTMLCanvasElement): Promise<RasterImage | null> {
  if (element.width < 2 || element.height < 2) {
    return null;
  }
  return rasterize(element, element.width, element.height);
}

function drawingXml(ctx: Context, image: RasterImage, description: string): string {
  const index = ctx.media.length + 1;
  const name = `image${index}.png`;
  ctx.media.push({ name, data: image.data });
  const relId = addRel(ctx, REL_IMAGE, `media/${name}`, false);
  let cx = image.width * EMU_PER_PX;
  let cy = image.height * EMU_PER_PX;
  const scale = Math.min(1, MAX_IMAGE_EMU / cx, MAX_IMAGE_HEIGHT_EMU / cy);
  cx = Math.max(1, Math.round(cx * scale));
  cy = Math.max(1, Math.round(cy * scale));
  const id = ctx.nextDrawing;
  ctx.nextDrawing += 1;
  return (
    `<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${cx}" cy="${cy}"/>` +
    `<wp:docPr id="${id}" name="Picture ${id}" descr="${esc(description)}"/>` +
    '<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr>' +
    '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic>' +
    `<pic:nvPicPr><pic:cNvPr id="${id}" name="${name}"/><pic:cNvPicPr/></pic:nvPicPr>` +
    `<pic:blipFill><a:blip r:embed="${relId}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>` +
    `<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm>` +
    '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic>' +
    "</wp:inline></w:drawing></w:r>"
  );
}

// ---------- inline content ----------

function safeHref(href: string): string | null {
  try {
    const url = new URL(href, window.location.href);
    if (url.protocol === "http:" || url.protocol === "https:" || url.protocol === "mailto:") {
      return url.href;
    }
  } catch {
    // Not a valid URL.
  }
  return null;
}

async function inlineChildren(parent: Node, ctx: Context, style: RunStyle): Promise<string> {
  let out = "";
  for (const child of Array.from(parent.childNodes)) {
    out += await inlineNode(child, ctx, style);
  }
  return out;
}

async function inlineNode(node: Node, ctx: Context, style: RunStyle): Promise<string> {
  if (node instanceof Text) {
    const text = (node.textContent ?? "").replace(/[\s ]+/g, " ");
    return textRun(text, style);
  }
  if (!(node instanceof Element) || isSkipped(node)) {
    return "";
  }
  if (isKatex(node)) {
    const source = katexSource(node);
    return source ? textRun(source, { ...style, code: true }) : "";
  }
  const tag = node.tagName.toLowerCase();
  style = screenStyle(node, style, ctx, true);
  switch (tag) {
    case "br":
      return "<w:r><w:br/></w:r>";
    case "wbr":
      return "";
    case "strong":
    case "b":
      return inlineChildren(node, ctx, { ...style, b: true });
    case "em":
    case "i":
    case "cite":
    case "dfn":
      return inlineChildren(node, ctx, { ...style, i: true });
    case "del":
    case "s":
    case "strike":
      return inlineChildren(node, ctx, { ...style, s: true });
    case "u":
    case "ins":
      return inlineChildren(node, ctx, { ...style, u: true });
    case "sup":
      return inlineChildren(node, ctx, { ...style, sup: true, sub: false });
    case "sub":
      return inlineChildren(node, ctx, { ...style, sub: true, sup: false });
    case "code":
    case "kbd":
    case "samp":
    case "tt": {
      return textRun((node.textContent ?? "").replace(/[\s ]+/g, " "), { ...style, code: true });
    }
    case "a": {
      const href = node instanceof HTMLAnchorElement ? safeHref(node.getAttribute("href") ?? "") : null;
      if (!href) {
        return inlineChildren(node, ctx, style);
      }
      const relId = addRel(ctx, REL_LINK, href, true);
      const runs = await inlineChildren(node, ctx, { ...style, link: true });
      return runs ? `<w:hyperlink r:id="${relId}" w:history="1">${runs}</w:hyperlink>` : "";
    }
    case "input": {
      if (node instanceof HTMLInputElement && node.type === "checkbox") {
        return textRun(node.checked ? "☑ " : "☐ ", style);
      }
      return "";
    }
    case "img": {
      if (!(node instanceof HTMLImageElement)) {
        return "";
      }
      const image = await imageFromElement(node);
      if (image) {
        return drawingXml(ctx, image, node.alt);
      }
      return node.alt ? textRun(`[${node.alt}]`, { ...style, i: true }) : "";
    }
    case "canvas": {
      if (!(node instanceof HTMLCanvasElement)) {
        return "";
      }
      const image = await imageFromCanvas(node);
      return image ? drawingXml(ctx, image, "") : "";
    }
    case "svg": {
      if (!(node instanceof SVGElement)) {
        return "";
      }
      const image = await imageFromSVG(node);
      return image ? drawingXml(ctx, image, "") : "";
    }
    default:
      return inlineChildren(node, ctx, style);
  }
}

// ---------- block content ----------

function paragraph(runs: string, state: BlockState, extra = ""): string {
  // Child order follows the WordprocessingML schema (pStyle, numPr, pBdr, shd, ind, jc).
  let pPr = extra;
  let indent = "";
  if (state.item && !state.item.used) {
    state.item.used = true;
    pPr += `<w:numPr><w:ilvl w:val="${state.item.ilvl}"/><w:numId w:val="${state.item.numId}"/></w:numPr>`;
  } else if (state.item || state.quote > 0 || state.level > 0) {
    indent = `<w:ind w:left="${LIST_INDENT * state.level + 360 * state.quote}"/>`;
  }
  const border = state.box?.border;
  if (border || state.quote > 0) {
    const side = (name: string) => `<w:${name} w:val="single" w:sz="4" w:space="4" w:color="${border}"/>`;
    const left =
      state.quote > 0 ? '<w:left w:val="single" w:sz="18" w:space="8" w:color="B0B7C0"/>' : border ? side("left") : "";
    pPr += `<w:pBdr>${border ? side("top") : ""}${left}${border ? side("bottom") + side("right") : ""}</w:pBdr>`;
  }
  if (state.box?.fill) {
    pPr += `<w:shd w:val="clear" w:color="auto" w:fill="${state.box.fill}"/>`;
  }
  pPr += indent;
  if (state.align && state.align !== "left") {
    pPr += `<w:jc w:val="${state.align}"/>`;
  }
  return `<w:p>${pPr ? `<w:pPr>${pPr}</w:pPr>` : ""}${runs}</w:p>`;
}

function trimRuns(runs: string): string {
  return runs;
}

async function convertList(list: Element, ctx: Context, state: BlockState): Promise<string[]> {
  const ordered = tagOf(list) === "ol";
  let numId = 1;
  if (ordered) {
    ctx.orderedLists += 1;
    numId = 1 + ctx.orderedLists;
    const start = list instanceof HTMLOListElement && Number.isFinite(list.start) ? list.start : 1;
    let overrides = "";
    for (let level = 0; level < 9; level += 1) {
      overrides += `<w:lvlOverride w:ilvl="${level}"><w:startOverride w:val="${level === 0 ? start : 1}"/></w:lvlOverride>`;
    }
    ctx.numbering.push(`<w:num w:numId="${numId}"><w:abstractNumId w:val="1"/>${overrides}</w:num>`);
  }
  const out: string[] = [];
  const ilvl = Math.min(state.level, 8);
  for (const child of Array.from(list.children)) {
    if (isSkipped(child)) {
      continue;
    }
    if (tagOf(child) !== "li") {
      out.push(...(await convertBlocks(child, ctx, state)));
      continue;
    }
    const item = { numId, ilvl, used: false };
    const inner = await convertBlocks(child, ctx, { ...state, level: state.level + 1, item });
    if (!item.used) {
      // Empty list item: still emit the bullet / number.
      out.push(paragraph("", { ...state, level: state.level + 1, item }));
    }
    out.push(...inner);
  }
  return out;
}

function cellAlign(cell: Element): "left" | "center" | "right" | undefined {
  const align = window.getComputedStyle(cell).textAlign;
  if (align === "center") {
    return "center";
  }
  if (align === "right" || align === "end") {
    return "right";
  }
  return undefined;
}

async function convertTable(table: Element, ctx: Context): Promise<string[]> {
  const rows = Array.from(
    table.querySelectorAll(":scope > thead > tr, :scope > tbody > tr, :scope > tfoot > tr, :scope > tr"),
  );
  if (rows.length === 0) {
    return [];
  }
  const cellsOf = (row: Element) =>
    Array.from(row.children).filter((cell) => {
      const tag = tagOf(cell);
      return (tag === "td" || tag === "th") && !isSkipped(cell);
    });
  const columns = Math.max(
    1,
    ...rows.map((row) =>
      cellsOf(row).reduce((sum, cell) => sum + (cell instanceof HTMLTableCellElement ? Math.max(1, cell.colSpan) : 1), 0),
    ),
  );
  const colWidth = Math.floor(TEXT_WIDTH_DXA / columns);
  let xml = '<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="5000" w:type="pct"/>';
  xml += '<w:tblLayout w:type="fixed"/><w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/></w:tblPr>';
  xml += `<w:tblGrid>${`<w:gridCol w:w="${colWidth}"/>`.repeat(columns)}</w:tblGrid>`;
  for (const row of rows) {
    xml += "<w:tr>";
    for (const cell of cellsOf(row)) {
      const header = tagOf(cell) === "th";
      const span = cell instanceof HTMLTableCellElement ? Math.max(1, cell.colSpan) : 1;
      const blocks = await convertBlocks(cell, ctx, {
        level: 0,
        quote: 0,
        style: screenStyle(cell, header ? { b: true } : {}, ctx, false),
        align: cellAlign(cell),
      });
      xml += `<w:tc><w:tcPr><w:tcW w:w="${colWidth * span}" w:type="dxa"/>`;
      if (span > 1) {
        xml += `<w:gridSpan w:val="${span}"/>`;
      }
      const fill = ownFill(window.getComputedStyle(cell), ctx) ?? ownFill(window.getComputedStyle(row), ctx);
      if (fill || header) {
        xml += `<w:shd w:val="clear" w:color="auto" w:fill="${fill ?? "F1F3F5"}"/>`;
      }
      xml += "</w:tcPr>";
      xml += blocks.length > 0 ? blocks.join("") : "<w:p/>";
      // A cell must end with a paragraph.
      if (blocks.length > 0 && blocks[blocks.length - 1].startsWith("<w:tbl>")) {
        xml += "<w:p/>";
      }
      xml += "</w:tc>";
    }
    xml += "</w:tr>";
  }
  xml += "</w:tbl>";
  return [xml, '<w:p><w:pPr><w:spacing w:after="0" w:line="120" w:lineRule="exact"/></w:pPr></w:p>'];
}

function codeLines(pre: Element): string[] {
  const code = pre.querySelector("code");
  const text = (code ?? pre).textContent ?? "";
  const lines = text.replace(/\r\n?/g, "\n").replace(/\n+$/, "").split("\n");
  return lines;
}

async function convertBlocks(parent: Node, ctx: Context, state: BlockState): Promise<string[]> {
  const out: string[] = [];
  let buffer = "";
  const flush = () => {
    const runs = trimRuns(buffer);
    buffer = "";
    if (runs.replace(/<[^>]+>/g, "").trim() !== "" || runs.includes("<w:drawing>") || runs.includes("<w:br/>")) {
      out.push(paragraph(runs, state));
    }
  };

  for (const child of Array.from(parent.childNodes)) {
    if (child instanceof Element && isSkipped(child)) {
      continue;
    }
    if (!isBlockNode(child)) {
      buffer += await inlineNode(child, ctx, state.style);
      continue;
    }
    if (!(child instanceof Element)) {
      continue;
    }
    flush();
    const tag = child.tagName.toLowerCase();
    const own = blockState(child, state, ctx);
    if (isKatex(child)) {
      const source = katexSource(child);
      if (source) {
        out.push(paragraph(textRun(source, { ...state.style, code: true }), { ...state, align: "center" }));
      }
      continue;
    }
    if (/^h[1-6]$/.test(tag)) {
      const runs = await inlineChildren(child, ctx, own.style);
      if (runs) {
        out.push(paragraph(runs, { ...own, item: undefined }, `<w:pStyle w:val="Heading${tag[1]}"/>`));
      }
    } else if (tag === "p") {
      const runs = await inlineChildren(child, ctx, own.style);
      if (runs) {
        out.push(paragraph(runs, own));
      }
    } else if (tag === "ul" || tag === "ol") {
      out.push(...(await convertList(child, ctx, own)));
    } else if (tag === "pre") {
      const lines = codeLines(child);
      lines.forEach((line, index) => {
        const last = index === lines.length - 1;
        const spacing = last ? '<w:spacing w:after="160"/>' : "";
        const runs = textRun(line, { code: true });
        out.push(`<w:p><w:pPr><w:pStyle w:val="Code"/>${spacing}</w:pPr>${runs}</w:p>`);
      });
    } else if (tag === "blockquote") {
      out.push(...(await convertBlocks(child, ctx, { ...own, item: undefined, quote: state.quote + 1 })));
    } else if (tag === "table") {
      out.push(...(await convertTable(child, ctx)));
    } else if (tag === "hr") {
      out.push('<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="B0B7C0"/></w:pBdr></w:pPr></w:p>');
    } else if (tag === "svg") {
      if (child instanceof SVGElement) {
        const image = await imageFromSVG(child);
        if (image) {
          out.push(paragraph(drawingXml(ctx, image, ""), own));
        }
      }
    } else if (tag === "summary") {
      const runs = await inlineChildren(child, ctx, { ...own.style, b: true });
      if (runs) {
        out.push(paragraph(runs, own));
      }
    } else {
      out.push(...(await convertBlocks(child, ctx, own)));
    }
  }
  flush();
  return out;
}

// ---------- package parts ----------

const NS =
  'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" ' +
  'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" ' +
  'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" ' +
  'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" ' +
  'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"';

const XML_HEAD = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';

function headingStyle(level: number, size: number, before: number): string {
  return (
    `<w:style w:type="paragraph" w:styleId="Heading${level}"><w:name w:val="heading ${level}"/>` +
    '<w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:uiPriority w:val="9"/><w:qFormat/>' +
    `<w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="${before}" w:after="80"/><w:outlineLvl w:val="${level - 1}"/></w:pPr>` +
    `<w:rPr><w:b/><w:bCs/><w:color w:val="1F2937"/><w:sz w:val="${size}"/><w:szCs w:val="${size}"/></w:rPr></w:style>`
  );
}

function stylesXml(base: ScreenBase): string {
  return (
    `${XML_HEAD}<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">` +
    `<w:docDefaults><w:rPrDefault><w:rPr>${fontsXml(base.font)}` +
    `${base.dark || base.color === "000000" ? "" : `<w:color w:val="${base.color}"/>`}` +
    `<w:sz w:val="${base.size}"/><w:szCs w:val="${base.size}"/><w:lang w:val="ru-RU" w:eastAsia="zh-CN" w:bidi="ar-SA"/></w:rPr></w:rPrDefault>` +
    '<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>' +
    '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>' +
    '<w:style w:type="character" w:default="1" w:styleId="DefaultParagraphFont"><w:name w:val="Default Paragraph Font"/><w:uiPriority w:val="1"/><w:semiHidden/></w:style>' +
    headingStyle(1, 36, 320) +
    headingStyle(2, 30, 280) +
    headingStyle(3, 26, 240) +
    headingStyle(4, 24, 200) +
    headingStyle(5, 22, 200) +
    headingStyle(6, 22, 200) +
    '<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>' +
    '<w:pPr><w:spacing w:after="240"/></w:pPr><w:rPr><w:b/><w:color w:val="111827"/><w:sz w:val="44"/><w:szCs w:val="44"/></w:rPr></w:style>' +
    '<w:style w:type="paragraph" w:styleId="RoleLabel"><w:name w:val="Role Label"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/>' +
    '<w:pPr><w:keepNext/><w:pBdr><w:bottom w:val="single" w:sz="4" w:space="2" w:color="D1D5DB"/></w:pBdr><w:spacing w:before="320" w:after="120"/></w:pPr>' +
    '<w:rPr><w:b/><w:color w:val="4B5563"/><w:sz w:val="22"/></w:rPr></w:style>' +
    '<w:style w:type="paragraph" w:styleId="Code"><w:name w:val="Code"/><w:basedOn w:val="Normal"/><w:qFormat/>' +
    '<w:pPr><w:shd w:val="clear" w:color="auto" w:fill="F3F4F6"/><w:spacing w:after="0" w:line="240" w:lineRule="auto"/><w:ind w:left="113" w:right="113"/></w:pPr>' +
    '<w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:cs="Consolas" w:eastAsia="Consolas"/><w:sz w:val="19"/><w:szCs w:val="19"/></w:rPr></w:style>' +
    '<w:style w:type="character" w:styleId="Hyperlink"><w:name w:val="Hyperlink"/><w:uiPriority w:val="99"/><w:rPr><w:color w:val="0563C1"/><w:u w:val="single"/></w:rPr></w:style>' +
    '<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:uiPriority w:val="99"/><w:semiHidden/>' +
    '<w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>' +
    '<w:style w:type="table" w:styleId="TableGrid"><w:name w:val="Table Grid"/><w:basedOn w:val="TableNormal"/><w:uiPriority w:val="39"/>' +
    '<w:pPr><w:spacing w:before="40" w:after="40" w:line="240" w:lineRule="auto"/></w:pPr>' +
    '<w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="BFC5CC"/><w:left w:val="single" w:sz="4" w:space="0" w:color="BFC5CC"/>' +
    '<w:bottom w:val="single" w:sz="4" w:space="0" w:color="BFC5CC"/><w:right w:val="single" w:sz="4" w:space="0" w:color="BFC5CC"/>' +
    '<w:insideH w:val="single" w:sz="4" w:space="0" w:color="BFC5CC"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="BFC5CC"/></w:tblBorders></w:tblPr></w:style>' +
    "</w:styles>"
  );
}

function numberingXml(extra: readonly string[]): string {
  const bullets = ["•", "◦", "▪"];
  let bullet = "";
  let decimal = "";
  const formats = ["decimal", "lowerLetter", "lowerRoman"];
  for (let level = 0; level < 9; level += 1) {
    const left = LIST_INDENT * (level + 1);
    bullet +=
      `<w:lvl w:ilvl="${level}"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="${bullets[level % 3]}"/>` +
      `<w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${left}" w:hanging="360"/></w:pPr>` +
      '<w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/></w:rPr></w:lvl>';
    decimal +=
      `<w:lvl w:ilvl="${level}"><w:start w:val="1"/><w:numFmt w:val="${formats[level % 3]}"/><w:lvlText w:val="%${level + 1}."/>` +
      `<w:lvlJc w:val="left"/><w:pPr><w:ind w:left="${left}" w:hanging="360"/></w:pPr></w:lvl>`;
  }
  return (
    `${XML_HEAD}<w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">` +
    `<w:abstractNum w:abstractNumId="0"><w:multiLevelType w:val="hybridMultilevel"/>${bullet}</w:abstractNum>` +
    `<w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="hybridMultilevel"/>${decimal}</w:abstractNum>` +
    '<w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>' +
    `${extra.join("")}</w:numbering>`
  );
}

function relsXml(rels: readonly Relationship[]): string {
  const base: Relationship[] = [
    { id: "rIdStyles", type: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles", target: "styles.xml", external: false },
    { id: "rIdNumbering", type: "http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering", target: "numbering.xml", external: false },
  ];
  const items = [...base, ...rels]
    .map(
      (rel) =>
        `<Relationship Id="${rel.id}" Type="${rel.type}" Target="${esc(rel.target)}"${rel.external ? ' TargetMode="External"' : ""}/>`,
    )
    .join("");
  return `${XML_HEAD}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${items}</Relationships>`;
}

function coreXml(title: string): string {
  const now = new Date().toISOString().replace(/\.\d+Z$/, "Z");
  return (
    `${XML_HEAD}<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" ` +
    'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" ' +
    'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' +
    `<dc:title>${esc(title)}</dc:title><dc:creator>DEEIX Chat</dc:creator>` +
    `<dcterms:created xsi:type="dcterms:W3CDTF">${now}</dcterms:created></cp:coreProperties>`
  );
}

const CONTENT_TYPES =
  `${XML_HEAD}<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">` +
  '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
  '<Default Extension="xml" ContentType="application/xml"/>' +
  '<Default Extension="png" ContentType="image/png"/>' +
  '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>' +
  '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>' +
  '<Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>' +
  '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>' +
  "</Types>";

const ROOT_RELS =
  `${XML_HEAD}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">` +
  '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>' +
  '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>' +
  "</Relationships>";

// ---------- public API ----------

/** The part of a message row that is worth exporting: the answer text without the process trace. */
export function docxContentRoot(row: HTMLElement): HTMLElement {
  return row.querySelector<HTMLElement>("[data-chat-assistant-content]") ?? row;
}

export function docxFileName(title: string): string {
  const cleaned = title
    // biome-ignore lint/suspicious/noControlCharactersInRegex: stripping characters invalid in file names
    .replace(/[\\/:*?"<>|\u0000-\u001F]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 80)
    .trim();
  return `${cleaned || "DEEIX Chat"}.docx`;
}

/** Builds the .docx file for the given messages. */
export async function buildDocx(
  messages: readonly DocxExportMessage[],
  options: DocxExportOptions,
): Promise<Blob | null> {
  const main = messages.find((message) => message.role === "assistant") ?? messages[0];
  const ctx: Context = {
    rels: [],
    media: [],
    orderedLists: 0,
    numbering: [],
    nextRel: 1,
    nextDrawing: 1,
    base: screenBase(main ? docxContentRoot(main.element) : undefined),
  };
  const body: string[] = [];
  if (options.showTitle && options.title) {
    body.push(`<w:p><w:pPr><w:pStyle w:val="Title"/></w:pPr>${textRun(options.title, {})}</w:p>`);
  }
  for (const message of messages) {
    if (options.roleLabels) {
      const label = message.role === "user" ? options.roleLabels.user : options.roleLabels.assistant;
      body.push(`<w:p><w:pPr><w:pStyle w:val="RoleLabel"/></w:pPr>${textRun(label, {})}</w:p>`);
    }
    const blocks = await convertBlocks(docxContentRoot(message.element), ctx, { level: 0, quote: 0, style: {} });
    body.push(...blocks);
    if (blocks.length > 0 && blocks[blocks.length - 1].startsWith("<w:tbl>")) {
      body.push("<w:p/>");
    }
  }
  if (body.length === 0) {
    return null;
  }
  const section =
    '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="567" w:footer="567" w:gutter="0"/></w:sectPr>';
  const documentXml = `${XML_HEAD}<w:document ${NS}><w:body>${body.join("")}${section}</w:body></w:document>`;

  const encoder = new TextEncoder();
  const zip = createZip([
    { name: "[Content_Types].xml", data: encoder.encode(CONTENT_TYPES) },
    { name: "_rels/.rels", data: encoder.encode(ROOT_RELS) },
    { name: "docProps/core.xml", data: encoder.encode(coreXml(options.title)) },
    { name: "word/document.xml", data: encoder.encode(documentXml) },
    { name: "word/styles.xml", data: encoder.encode(stylesXml(ctx.base)) },
    { name: "word/numbering.xml", data: encoder.encode(numberingXml(ctx.numbering)) },
    { name: "word/_rels/document.xml.rels", data: encoder.encode(relsXml(ctx.rels)) },
    ...ctx.media.map((file) => ({ name: `word/media/${file.name}`, data: file.data })),
  ]);
  return new Blob([zip], {
    type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  });
}

/** Builds the document and starts the download. Resolves to false when there was nothing to export. */
export async function exportMessagesAsDocx(
  messages: readonly DocxExportMessage[],
  options: DocxExportOptions,
): Promise<boolean> {
  if (messages.length === 0) {
    return false;
  }
  const blob = await buildDocx(messages, options);
  if (!blob) {
    return false;
  }
  downloadBlob(blob, docxFileName(options.title));
  return true;
}
