// Minimal .xlsx writer for tables in answers (deeix-ru add-on, no extra dependencies).
// One sheet: a bold header row that stays on screen while scrolling, an autofilter,
// column widths from the content, long or multi-line text wrapped, numbers as numbers.

import { createZip } from "@/shared/lib/zip-writer";

export type XlsxCell = string | number | boolean | null | undefined;

export type XlsxTable = {
  sheetName?: string;
  headers: readonly string[];
  rows: readonly (readonly XlsxCell[])[];
};

const MIN_WIDTH = 6;
const MAX_WIDTH = 60;
const WRAP_FROM = 50;
// Plain digit strings longer than this (INN, OGRN, account and phone numbers) stay text,
// otherwise Excel would show them as 7.7E+09 or drop digits past the 15th.
const MAX_PLAIN_DIGITS = 9;
const MAX_NUMBER_DIGITS = 15;

// Style indexes in styles.xml: 0 default, 1 header, 2 wrapped text, 3 header wrapped,
// 4 whole number with thousands separators, 5 number with two decimals, 6 plain value
// (set on every cell: some apps ignore the alignment of the default style).
const STYLE_HEADER = 1;
const STYLE_WRAP = 2;
const STYLE_THOUSANDS = 4;
const STYLE_DECIMAL = 5;
const STYLE_PLAIN = 6;

function numberStyle(value: number): string {
  if (!Number.isInteger(value)) return ` s="${STYLE_DECIMAL}"`;
  return ` s="${Math.abs(value) >= 10000 ? STYLE_THOUSANDS : STYLE_PLAIN}"`;
}

// XML 1.0 forbids control characters other than tab, line feed and carriage return.
function dropInvalidXmlChars(value: string): string {
  let out = "";
  for (const char of value) {
    const code = char.codePointAt(0) ?? 0;
    if (code < 32 && code !== 9 && code !== 10 && code !== 13) continue;
    if (code === 0xfffe || code === 0xffff || (code >= 0xd800 && code <= 0xdfff)) continue;
    out += char;
  }
  return out;
}

function xmlEscape(value: string): string {
  return dropInvalidXmlChars(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function columnName(index: number): string {
  let name = "";
  let n = index + 1;
  while (n > 0) {
    const rest = (n - 1) % 26;
    name = String.fromCharCode(65 + rest) + name;
    n = Math.floor((n - 1) / 26);
  }
  return name;
}

const GROUPED = /^[+-]?\d{1,3}(?:[   ]\d{3})+(?:[.,]\d+)?$/;
const PLAIN = /^[+-]?\d+(?:[.,]\d+)?$/;
const EN_THOUSANDS = /^[+-]?\d{1,3}(?:,\d{3})+$/;

// Reads "1 234,56", "1234.5", "-7" as numbers. Anything unclear stays text: "1,234"
// (thousands or a decimal comma?), "007", "12%", dates, long digit strings.
export function parseXlsxNumber(raw: string): number | null {
  const text = raw.trim();
  if (text === "" || text.length > 24) return null;
  if (EN_THOUSANDS.test(text)) return null;
  const grouped = GROUPED.test(text);
  if (!grouped && !PLAIN.test(text)) return null;
  const unsigned = text.replace(/^[+-]/, "");
  if (/^0\d/.test(unsigned)) return null;
  const digits = unsigned.replace(/\D/g, "").length;
  const hasFraction = /[.,]/.test(unsigned);
  if (!grouped && !hasFraction && digits > MAX_PLAIN_DIGITS) return null;
  if (digits > MAX_NUMBER_DIGITS) return null;
  const value = Number(text.replace(/[   ]/g, "").replace(",", "."));
  return Number.isFinite(value) ? value : null;
}

function longestLine(text: string): number {
  let longest = 0;
  for (const line of text.split("\n")) {
    if (line.length > longest) longest = line.length;
  }
  return longest;
}

function cellText(value: XlsxCell): string {
  if (value === null || value === undefined) return "";
  return String(value);
}

export function sanitizeSheetName(name: string | undefined): string {
  const cleaned = (name ?? "").replace(/[[\]:*?/\\]/g, " ").replace(/\s+/g, " ").trim().replace(/^'+|'+$/g, "");
  return (cleaned || "Sheet1").slice(0, 31);
}

function sheetXml(table: XlsxTable): string {
  const columnCount = Math.max(table.headers.length, ...table.rows.map((row) => row.length), 1);
  const widths: number[] = [];
  const wraps: boolean[] = [];
  for (let col = 0; col < columnCount; col += 1) {
    let longest = longestLine(table.headers[col] ?? "");
    let multiline = false;
    for (const row of table.rows) {
      const text = cellText(row[col]);
      if (text.includes("\n")) multiline = true;
      const length = longestLine(text);
      if (length > longest) longest = length;
    }
    widths.push(Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, longest + 2)));
    wraps.push(multiline || longest > WRAP_FROM);
  }

  const rowsXml: string[] = [];
  const headerCells = Array.from({ length: columnCount }, (_, col) => {
    const ref = `${columnName(col)}1`;
    const style = wraps[col] ? STYLE_HEADER + 2 : STYLE_HEADER;
    return `<c r="${ref}" s="${style}" t="inlineStr"><is><t xml:space="preserve">${xmlEscape(table.headers[col] ?? "")}</t></is></c>`;
  });
  rowsXml.push(`<row r="1">${headerCells.join("")}</row>`);

  table.rows.forEach((row, rowIndex) => {
    const r = rowIndex + 2;
    const cells: string[] = [];
    for (let col = 0; col < columnCount; col += 1) {
      const value = row[col];
      if (value === null || value === undefined || value === "") continue;
      const ref = `${columnName(col)}${r}`;
      const style = ` s="${wraps[col] ? STYLE_WRAP : STYLE_PLAIN}"`;
      if (typeof value === "boolean") {
        cells.push(`<c r="${ref}"${style} t="b"><v>${value ? 1 : 0}</v></c>`);
        continue;
      }
      const number = typeof value === "number" ? (Number.isFinite(value) ? value : null) : parseXlsxNumber(value);
      if (number !== null) {
        cells.push(`<c r="${ref}"${numberStyle(number)}><v>${number}</v></c>`);
        continue;
      }
      cells.push(`<c r="${ref}"${style} t="inlineStr"><is><t xml:space="preserve">${xmlEscape(String(value))}</t></is></c>`);
    }
    rowsXml.push(`<row r="${r}">${cells.join("")}</row>`);
  });

  const lastRef = `${columnName(columnCount - 1)}${table.rows.length + 1}`;
  const cols = widths.map((width, col) => `<col min="${col + 1}" max="${col + 1}" width="${width}" customWidth="1"/>`).join("");
  return (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
    '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
    `<dimension ref="A1:${lastRef}"/>` +
    '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A2" sqref="A2"/></sheetView></sheetViews>' +
    '<sheetFormatPr defaultRowHeight="15"/>' +
    `<cols>${cols}</cols>` +
    `<sheetData>${rowsXml.join("")}</sheetData>` +
    (table.rows.length > 0 ? `<autoFilter ref="A1:${lastRef}"/>` : "") +
    '<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>' +
    "</worksheet>"
  );
}

const STYLES_XML =
  '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
  '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
  '<fonts count="2"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font><font><b/><sz val="11"/><name val="Calibri"/><family val="2"/></font></fonts>' +
  '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>' +
  '<fill><patternFill patternType="solid"><fgColor rgb="FFE7EEF3"/><bgColor indexed="64"/></patternFill></fill></fills>' +
  '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>' +
  '<border><left/><right/><top/><bottom style="thin"><color rgb="FF9AA9B4"/></bottom><diagonal/></border></borders>' +
  '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
  '<cellXfs count="7">' +
  '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' +
  '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>' +
  '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>' +
  '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>' +
  '<xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyAlignment="1"><alignment vertical="top"/></xf>' +
  '<xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyAlignment="1"><alignment vertical="top"/></xf>' +
  '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top"/></xf>' +
  "</cellXfs>" +
  '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>' +
  "</styleSheet>";

export function buildXlsx(table: XlsxTable): Uint8Array<ArrayBuffer> {
  const encoder = new TextEncoder();
  const sheetName = sanitizeSheetName(table.sheetName);
  const files: [string, string][] = [
    [
      "[Content_Types].xml",
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
        '<Default Extension="xml" ContentType="application/xml"/>' +
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
        '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' +
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
        "</Types>",
    ],
    [
      "_rels/.rels",
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' +
        "</Relationships>",
    ],
    [
      "xl/workbook.xml",
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
        `<sheets><sheet name="${xmlEscape(sheetName)}" sheetId="1" r:id="rId1"/></sheets>` +
        (table.rows.length > 0
          ? `<definedNames><definedName name="_xlnm._FilterDatabase" localSheetId="0" hidden="1">'${xmlEscape(sheetName.replaceAll("'", "''"))}'!$A$1:$${columnName(Math.max(table.headers.length, ...table.rows.map((row) => row.length), 1) - 1)}$${table.rows.length + 1}</definedName></definedNames>`
          : "") +
        "</workbook>",
    ],
    [
      "xl/_rels/workbook.xml.rels",
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>' +
        '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' +
        "</Relationships>",
    ],
    ["xl/styles.xml", STYLES_XML],
    ["xl/worksheets/sheet1.xml", sheetXml(table)],
  ];
  return createZip(files.map(([name, text]) => ({ name, data: encoder.encode(text) })));
}

export const XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

// File names keep letters of any script; characters Windows refuses are replaced.
export function xlsxFileName(title: string | undefined, fallback: string): string {
  const visible = Array.from(title ?? "", (char) => ((char.codePointAt(0) ?? 0) < 32 ? " " : char)).join("");
  const base = visible.replace(/[\\/:*?"<>|]/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
  return `${base || fallback}.xlsx`;
}
