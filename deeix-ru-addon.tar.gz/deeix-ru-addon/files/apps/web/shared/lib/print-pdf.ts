"use client";

// Exports chat messages as PDF through the browser's print dialog ("Save as PDF").
// The message rows are cloned into a hidden iframe, stripped of interface controls, and printed
// with a light print stylesheet. The result is a vector PDF with selectable text. Part of the
// deeix-ru add-on; it does not use any extra dependency.

export const OMIT_SELECTOR = [
  "[data-screenshot-exclude='true']",
  "[data-screenshot-only='true']",
  ".chat-message-meta",
  ".chat-screenshot-omit",
  "[data-streamdown='code-block-actions']",
  "[data-streamdown='mermaid-block-actions']",
  "[data-radix-popper-content-wrapper]",
].join(",");

const PRINT_CSS = `
@page { margin: 16mm 14mm; }
:root { color-scheme: light; }
html, body { height: auto !important; min-height: 0 !important; overflow: visible !important; background: #fff !important; margin: 0 !important; padding: 0 !important; }
* { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
.pdf-export-root { display: block; width: auto; max-width: none; margin: 0; padding: 0; }
.pdf-export-row { display: block; margin: 0 0 14px; padding: 0; }
.pdf-export-root * { max-height: none !important; animation: none !important; transition: none !important; }
.pdf-export-root [class*="sticky"], .pdf-export-root [class*="fixed"] { position: static !important; }
.pdf-export-root pre, .pdf-export-root code { white-space: pre-wrap !important; word-break: break-word; overflow: visible !important; }
.pdf-export-root pre { break-inside: auto; }
.pdf-export-root img, .pdf-export-root svg, .pdf-export-root canvas { max-width: 100%; height: auto; }
.pdf-export-root table { max-width: 100%; }
.pdf-export-root tr, .pdf-export-root img { break-inside: avoid; }
.pdf-export-root h1, .pdf-export-root h2, .pdf-export-root h3 { break-after: avoid; }
`;

const ASSET_WAIT_MS = 4000;
const CLEANUP_FALLBACK_MS = 120_000;

type Locale = string | undefined;

/** Menu and button caption; the add-on keeps it here instead of adding keys to the message catalogs. */
export function pdfExportLabel(locale: Locale): string {
  if (locale?.toLowerCase().startsWith("ru")) {
    return "Экспорт в PDF";
  }
  if (locale?.toLowerCase().startsWith("zh")) {
    return "导出为 PDF";
  }
  return "Export PDF";
}

/** A short single-line title from free text, used as the default PDF file name. */
export function pdfTitleFromText(text: string, fallback = "DEEIX Chat"): string {
  const value = text.replace(/\s+/g, " ").trim();
  if (!value) {
    return fallback;
  }
  return value.length > 60 ? `${value.slice(0, 60).trim()}…` : value;
}

function waitFor(condition: () => boolean, timeoutMS: number): Promise<void> {
  return new Promise((resolve) => {
    const startedAt = Date.now();
    const tick = () => {
      if (condition() || Date.now() - startedAt >= timeoutMS) {
        resolve();
        return;
      }
      window.setTimeout(tick, 50);
    };
    tick();
  });
}

function copyStyles(target: Document): HTMLLinkElement[] {
  const links: HTMLLinkElement[] = [];
  const nodes = document.querySelectorAll("link[rel='stylesheet'], style");
  for (const node of nodes) {
    if (node instanceof HTMLLinkElement) {
      const link = target.createElement("link");
      link.rel = "stylesheet";
      link.href = node.href;
      target.head.appendChild(link);
      links.push(link);
    } else if (node instanceof HTMLStyleElement) {
      const style = target.createElement("style");
      style.textContent = node.textContent;
      target.head.appendChild(style);
    }
  }
  return links;
}

function cloneRow(source: HTMLElement, target: Document): HTMLElement {
  const clone = source.cloneNode(true);
  const wrapper = target.createElement("div");
  wrapper.className = "pdf-export-row";
  if (!(clone instanceof HTMLElement)) {
    return wrapper;
  }
  // Canvas content is not copied by cloneNode; replace each canvas with its current bitmap.
  const sourceCanvases = source.querySelectorAll("canvas");
  const clonedCanvases = clone.querySelectorAll("canvas");
  sourceCanvases.forEach((canvas, index) => {
    const copy = clonedCanvases[index];
    if (!copy) {
      return;
    }
    try {
      const image = target.createElement("img");
      image.src = canvas.toDataURL("image/png");
      copy.replaceWith(image);
    } catch {
      // A tainted canvas cannot be read; leave the empty canvas.
    }
  });
  for (const omitted of clone.querySelectorAll(OMIT_SELECTOR)) {
    omitted.remove();
  }
  for (const image of clone.querySelectorAll("img")) {
    image.loading = "eager";
  }
  // Assistant rows: keep the answer text, drop the "processing" / tool trace above it.
  const answer = clone.querySelector("[data-chat-assistant-content]");
  wrapper.appendChild(answer ?? clone);
  return wrapper;
}

/** Opens the print dialog for the given message rows. Resolves once the dialog was requested. */
export async function printElementsAsPDF(elements: readonly HTMLElement[], title: string): Promise<boolean> {
  if (elements.length === 0) {
    return false;
  }
  const frame = document.createElement("iframe");
  frame.setAttribute("aria-hidden", "true");
  frame.tabIndex = -1;
  frame.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden;";
  document.body.appendChild(frame);

  const frameWindow = frame.contentWindow;
  const frameDocument = frame.contentDocument;
  if (!frameWindow || !frameDocument) {
    frame.remove();
    return false;
  }

  frameDocument.open();
  frameDocument.write("<!doctype html><html><head><meta charset=\"utf-8\"></head><body></body></html>");
  frameDocument.close();
  frameDocument.title = title;
  frameDocument.documentElement.lang = document.documentElement.lang;
  // Keep font variables and the user's chosen fonts, but never the dark theme.
  frameDocument.documentElement.className = Array.from(document.documentElement.classList)
    .filter((name) => name !== "dark")
    .join(" ");
  frameDocument.body.className = Array.from(document.body.classList)
    .filter((name) => name !== "dark")
    .join(" ");
  frameDocument.documentElement.style.cssText = document.documentElement.style.cssText;

  const links = copyStyles(frameDocument);
  const printStyle = frameDocument.createElement("style");
  printStyle.textContent = PRINT_CSS;
  frameDocument.head.appendChild(printStyle);

  const root = frameDocument.createElement("div");
  root.className = "pdf-export-root";
  for (const element of elements) {
    root.appendChild(cloneRow(element, frameDocument));
  }
  frameDocument.body.appendChild(root);

  const stylesLoaded = links.map(
    (link) => new Promise<void>((resolve) => {
      link.addEventListener("load", () => resolve(), { once: true });
      link.addEventListener("error", () => resolve(), { once: true });
    }),
  );
  await Promise.race([
    Promise.all(stylesLoaded),
    new Promise<void>((resolve) => window.setTimeout(resolve, ASSET_WAIT_MS)),
  ]);
  const images = Array.from(frameDocument.images);
  await waitFor(() => images.every((image) => image.complete), ASSET_WAIT_MS);
  try {
    await frameDocument.fonts.ready;
  } catch {
    // Fonts API is optional.
  }

  const previousTitle = document.title;
  let cleaned = false;
  const cleanup = () => {
    if (cleaned) {
      return;
    }
    cleaned = true;
    document.title = previousTitle;
    window.setTimeout(() => frame.remove(), 300);
  };
  frameWindow.addEventListener("afterprint", cleanup, { once: true });
  window.setTimeout(cleanup, CLEANUP_FALLBACK_MS);

  // Chromium takes the default file name from the top document title.
  document.title = title;
  frameWindow.focus();
  frameWindow.print();
  return true;
}
