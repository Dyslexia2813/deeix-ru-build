#!/usr/bin/env bash
# Installs the Russian (ru-RU) locale and the scanned-PDF backend patch into a DEEIX Chat
# checkout without forking it.
#
#   ./install.sh [--check | --uninstall] [--no-scan-pdf] [--no-deepseek-anthropic] [--no-app-icon] /path/to/deeix-chat
#
# New files are copied in from files/. Existing files are changed by patches/*.patch,
# which are applied with git so a clean apply means the checkout is still the expected version.
# patches/scan-pdf.patch (backend) lets PDFs without a text layer be sent to vision models;
# pass --no-scan-pdf to skip it.
# patches/deepseek-anthropic.patch (backend) fixes tool calls for DeepSeek models connected through
# the Anthropic protocol; pass --no-deepseek-anthropic to skip it.
# patches/app-icon.patch replaces the browser and installed-app icons with the "D" letter and adds a
# version to the icon URLs in the backend defaults so browsers fetch the new files; pass --no-app-icon to skip it.
set -euo pipefail

ADDON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

MODE="install"
WITH_SCAN=1
WITH_DEEPSEEK=1
WITH_ICON=1
while [ $# -gt 0 ]; do
  case "$1" in
    --check) MODE="check"; shift ;;
    --uninstall) MODE="uninstall"; shift ;;
    --no-scan-pdf) WITH_SCAN=0; shift ;;
    --no-deepseek-anthropic) WITH_DEEPSEEK=0; shift ;;
    --no-app-icon) WITH_ICON=0; shift ;;
    *) break ;;
  esac
done

REPO="${1:?usage: install.sh [--check | --uninstall] /path/to/deeix-chat}"
if ! git -C "$REPO" rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "not a git checkout: $REPO" >&2
  exit 1
fi
cd "$REPO"

PATCHES=("ru-locale")
[ "$WITH_SCAN" = 1 ] && PATCHES+=("scan-pdf")
[ "$WITH_DEEPSEEK" = 1 ] && PATCHES+=("deepseek-anthropic")
[ "$WITH_ICON" = 1 ] && PATCHES+=("app-icon")

is_applied() { git apply --reverse --check "$ADDON_DIR/patches/$1.patch" >/dev/null 2>&1; }
applies_cleanly() { git apply --check "$ADDON_DIR/patches/$1.patch" >/dev/null 2>&1; }

copy_files() { cp -R "$ADDON_DIR/files/apps/web/." apps/web/; }

case "$MODE" in
  check)
    status=0
    for name in "${PATCHES[@]}"; do
      if is_applied "$name"; then
        echo "$name: installed"
      elif applies_cleanly "$name"; then
        echo "$name: not installed; the patch applies cleanly"
      else
        echo "$name: the patch does not apply to this checkout. See README.md, section 'Conflicts'." >&2
        status=1
      fi
    done
    exit "$status"
    ;;
  install)
    for name in "${PATCHES[@]}"; do
      if is_applied "$name"; then
        echo "$name: patch already applied"
      elif applies_cleanly "$name"; then
        git apply "$ADDON_DIR/patches/$name.patch"
        echo "$name: patch applied"
      else
        echo "$name: the patch does not apply to this checkout. See README.md, section 'Conflicts'." >&2
        exit 1
      fi
    done
    copy_files
    echo "files copied. Next: pnpm --filter @deeix/web check"
    ;;
  uninstall)
    for ((i = ${#PATCHES[@]} - 1; i >= 0; i--)); do
      name="${PATCHES[$i]}"
      if is_applied "$name"; then
        git apply --reverse "$ADDON_DIR/patches/$name.patch"
        echo "$name: patch reverted"
      else
        echo "$name: patch not applied, nothing to revert"
      fi
    done
    (cd "$ADDON_DIR/files" && find . -type f) | while IFS= read -r file; do rm -f "$file"; done
    find apps/web/i18n -type d -empty -delete 2>/dev/null || true
    echo "files removed"
    ;;
esac
