#!/usr/bin/env bash
# Installs the Russian (ru-RU) locale into a DEEIX Chat checkout without forking it.
#
#   ./install.sh [--check | --uninstall] /path/to/deeix-chat
#
# New files are copied in from files/. Existing files are changed by patches/ru-locale.patch,
# which is applied with git so a clean apply means the checkout is still the expected version.
set -euo pipefail

ADDON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$ADDON_DIR/patches/ru-locale.patch"

MODE="install"
case "${1:-}" in
  --check) MODE="check"; shift ;;
  --uninstall) MODE="uninstall"; shift ;;
esac

REPO="${1:?usage: install.sh [--check | --uninstall] /path/to/deeix-chat}"
if ! git -C "$REPO" rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "not a git checkout: $REPO" >&2
  exit 1
fi
cd "$REPO"

is_applied() { git apply --reverse --check "$PATCH" >/dev/null 2>&1; }
applies_cleanly() { git apply --check "$PATCH" >/dev/null 2>&1; }

copy_files() { cp -R "$ADDON_DIR/files/apps/web/." apps/web/; }

case "$MODE" in
  check)
    if is_applied; then
      echo "ru-RU: installed"
    elif applies_cleanly; then
      echo "ru-RU: not installed; the patch applies cleanly"
    else
      echo "ru-RU: the patch does not apply to this checkout. See README.md, section 'Conflicts'." >&2
      exit 1
    fi
    ;;
  install)
    if is_applied; then
      echo "ru-RU: patch already applied, refreshing files"
    elif applies_cleanly; then
      git apply "$PATCH"
      echo "ru-RU: patch applied"
    else
      echo "ru-RU: the patch does not apply to this checkout. See README.md, section 'Conflicts'." >&2
      exit 1
    fi
    copy_files
    echo "ru-RU: files copied. Next: pnpm --filter @deeix/web check"
    ;;
  uninstall)
    if is_applied; then
      git apply --reverse "$PATCH"
      echo "ru-RU: patch reverted"
    else
      echo "ru-RU: patch not applied, nothing to revert"
    fi
    (cd "$ADDON_DIR/files" && find . -type f) | while IFS= read -r file; do rm -f "$file"; done
    find apps/web/i18n -type d -empty -delete 2>/dev/null || true
    echo "ru-RU: files removed"
    ;;
esac
