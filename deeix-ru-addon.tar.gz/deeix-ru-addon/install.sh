#!/usr/bin/env bash
# Installs the Russian (ru-RU) locale and the scanned-PDF backend patch into a DEEIX Chat
# checkout without forking it.
#
#   ./install.sh [--check | --uninstall] [--no-scan-pdf] [--no-deepseek-anthropic] [--no-app-icon] [--no-table-fit] [--no-inline-html] [--no-composer-triggers] [--no-turn-resources] [--no-composer-bottom] [--no-usage-stats] [--no-focus-toggle] [--no-doc-text] /path/to/deeix-chat
#
# New files are copied in from files/. Existing files are changed by patches/*.patch,
# which are applied with git so a clean apply means the checkout is still the expected version.
# patches/scan-pdf.patch (backend) lets PDFs without a text layer be sent to vision models;
# pass --no-scan-pdf to skip it.
# patches/deepseek-anthropic.patch (backend) fixes tool calls for DeepSeek models connected through
# the Anthropic protocol; pass --no-deepseek-anthropic to skip it.
# patches/app-icon.patch replaces the browser and installed-app icons with the "D" letter and adds a
# version to the icon URLs in the backend defaults so browsers fetch the new files; pass --no-app-icon to skip it.
# patches/table-fit.patch (frontend) fits wide markdown tables in chat answers to the chat width and wraps
# cell text instead of scrolling sideways; pass --no-table-fit to skip it.
# patches/inline-html.patch (frontend) renders an html-visual fragment that the model wrapped in a ```html
# fence inside the answer instead of showing it as code; pass --no-inline-html to skip it.
# patches/composer-triggers.patch (frontend) adds "/" and "@" items to the composer "+" menu that open the same menus as
# typing those characters; pass --no-composer-triggers to skip it.
# patches/turn-resources.patch (frontend) adds a line under each answer with the skills attached to the request and the
# tools the model called, read from the message process trace; pass --no-turn-resources to skip it.
# patches/composer-bottom.patch (frontend) keeps the composer at the bottom of the empty new-chat screen, as in a
# conversation, so its menus open upward with room; pass --no-composer-bottom to skip it.
# patches/usage-stats.patch (backend) fixes the admin usage statistics on SQLite, which failed with an internal
# server error once an average latency reached 1 000 000 ms; pass --no-usage-stats to skip it.
# patches/focus-toggle.patch (frontend) adds a floating button next to "scroll to end" that hides the chat title bar and
# the composer so the answer gets more room; pass --no-focus-toggle to skip it.
# patches/doc-text.patch (backend) reads the text of old Word 97-2003 .doc files in Go; the official image has no antiword,
# so such files failed and the chat answered "file is not ready"; pass --no-doc-text to skip it.
set -euo pipefail

ADDON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

MODE="install"
WITH_SCAN=1
WITH_DEEPSEEK=1
WITH_ICON=1
WITH_TABLE_FIT=1
WITH_INLINE_HTML=1
WITH_TRIGGERS=1
WITH_TURN_RESOURCES=1
WITH_COMPOSER_BOTTOM=1
WITH_USAGE_STATS=1
WITH_FOCUS_TOGGLE=1
WITH_DOC_TEXT=1
while [ $# -gt 0 ]; do
  case "$1" in
    --check) MODE="check"; shift ;;
    --uninstall) MODE="uninstall"; shift ;;
    --no-scan-pdf) WITH_SCAN=0; shift ;;
    --no-deepseek-anthropic) WITH_DEEPSEEK=0; shift ;;
    --no-app-icon) WITH_ICON=0; shift ;;
    --no-table-fit) WITH_TABLE_FIT=0; shift ;;
    --no-inline-html) WITH_INLINE_HTML=0; shift ;;
    --no-composer-triggers) WITH_TRIGGERS=0; shift ;;
    --no-turn-resources) WITH_TURN_RESOURCES=0; shift ;;
    --no-composer-bottom) WITH_COMPOSER_BOTTOM=0; shift ;;
    --no-usage-stats) WITH_USAGE_STATS=0; shift ;;
    --no-focus-toggle) WITH_FOCUS_TOGGLE=0; shift ;;
    --no-doc-text) WITH_DOC_TEXT=0; shift ;;
    *) break ;;
  esac
done

REPO="${1:?usage: install.sh [--check | --uninstall] /path/to/deeix-chat}"
if ! git -C "$REPO" rev-parse --show-toplevel >/dev/null 2>&1; then
  echo "not a git checkout: $REPO" >&2
  exit 1
fi
cd "$REPO"

PATCHES=("ru-locale")
[ "$WITH_SCAN" = 1 ] && PATCHES+=("scan-pdf")
[ "$WITH_DEEPSEEK" = 1 ] && PATCHES+=("deepseek-anthropic")
[ "$WITH_ICON" = 1 ] && PATCHES+=("app-icon")
[ "$WITH_TABLE_FIT" = 1 ] && PATCHES+=("table-fit")
[ "$WITH_INLINE_HTML" = 1 ] && PATCHES+=("inline-html")
[ "$WITH_TRIGGERS" = 1 ] && PATCHES+=("composer-triggers")
[ "$WITH_TURN_RESOURCES" = 1 ] && PATCHES+=("turn-resources")
[ "$WITH_COMPOSER_BOTTOM" = 1 ] && PATCHES+=("composer-bottom")
[ "$WITH_USAGE_STATS" = 1 ] && PATCHES+=("usage-stats")
[ "$WITH_FOCUS_TOGGLE" = 1 ] && PATCHES+=("focus-toggle")
[ "$WITH_DOC_TEXT" = 1 ] && PATCHES+=("doc-text")

is_applied() { git apply --reverse --check "$ADDON_DIR/patches/$1.patch" >/dev/null 2>&1; }
applies_cleanly() { git apply --check "$ADDON_DIR/patches/$1.patch" >/dev/null 2>&1; }

copy_files() { cp -R "$ADDON_DIR/files/apps/web/." apps/web/; }

case "$MODE" in
  check)
    status=0
    for name in "${PATCHES[@]}"; do
      if is_applied "$name"; then
        echo "$name: installed"
      elif applies_cleanly "$name"; then
        echo "$name: not installed; the patch applies cleanly"
      else
        echo "$name: the patch does not apply to this checkout. See README.md, section 'Conflicts'." >&2
        status=1
      fi
    done
    exit "$status"
    ;;
  install)
    for name in "${PATCHES[@]}"; do
      if is_applied "$name"; then
        echo "$name: patch already applied"
      elif applies_cleanly "$name"; then
        git apply "$ADDON_DIR/patches/$name.patch"
        echo "$name: patch applied"
      else
        echo "$name: the patch does not apply to this checkout. See README.md, section 'Conflicts'." >&2
        exit 1
      fi
    done
    copy_files
    echo "files copied. Next: pnpm --filter @deeix/web check"
    ;;
  uninstall)
    for ((i = ${#PATCHES[@]} - 1; i >= 0; i--)); do
      name="${PATCHES[$i]}"
      if is_applied "$name"; then
        git apply --reverse "$ADDON_DIR/patches/$name.patch"
        echo "$name: patch reverted"
      else
        echo "$name: patch not applied, nothing to revert"
      fi
    done
    (cd "$ADDON_DIR/files" && find . -type f) | while IFS= read -r file; do rm -f "$file"; done
    find apps/web/i18n -type d -empty -delete 2>/dev/null || true
    echo "files removed"
    ;;
esac
