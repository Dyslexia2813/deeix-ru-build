# Глоссарий и стиль перевода DEEIX Chat на русский

Эталон стиля: уже переведённые `common.json`, `login.json`, `desktop-tabs.json`.

## Правила

- Обращение на «вы», нейтральный деловой тон. Без разговорных оборотов и без восклицаний, если их нет в оригинале.
- Регистр как в оригинале: если в английском заголовок с большой буквы только в начале («Sign in to DEEIX Chat»), в русском тоже только первое слово («Вход в DEEIX Chat»). Не использовать Title Case.
- Пунктуацию копировать из оригинала: точка в конце есть в английском, значит есть и в русском; многоточие `...` остаётся `...`.
- Переводить только значения. Ключи, порядок ключей и структуру не менять.
- Подстановки `{name}`, `{count}`, `{time}` и т. п., разметку `<b>…</b>` и плейсхолдеры `#` в ICU не менять и не переводить.
- ICU `plural`: в русском обязательно четыре формы `one`, `few`, `many`, `other`. Пример: `{count, plural, one {# модель} few {# модели} many {# моделей} other {# модели}}`. Если число в строке не выводится (`{count}` без plural), формулировать так, чтобы фраза не требовала склонения («Выбрано: {count}»).
- Единицы: «с» (секунда), «мин», «ч», «МБ», «ГБ» с пробелом перед единицей.
- Не переводить: DEEIX, DEEIX Chat, названия провайдеров и продуктов (OpenAI, Anthropic, Gemini, xAI, OpenRouter, Stripe, EPay, Turnstile, Docling, Tika, Redis и т. д.), аббревиатуры и протоколы (API, URL, JSON, MCP, RAG, OCR, SSO, OIDC, OAuth, SMTP, TOTP, 2FA, SQL, HTTP), имена полей конфигурации и пути в `code`-стиле, примеры значений.
- Если в оригинале технический идентификатор в кавычках или `code`, оставить как есть.
- Китайские, английские значения, которые служат названием языка («English», «简体中文»), не менять.
- Не переводить строки-примеры вроде `https://api.example.com`, `sk-...`.
- Отрицательные и конфиденциальные формулировки (ошибки, блокировки) переводить точно, без смягчения смысла.

## Термины

| English | Русский |
| --- | --- |
| chat (the product feature, noun) | чат |
| conversation | диалог |
| message | сообщение |
| assistant (role) | ассистент |
| prompt / system prompt | промпт / системный промпт |
| model | модель |
| platform model | платформенная модель |
| provider / vendor | провайдер / вендор |
| upstream | апстрим |
| channel | канал |
| route / routing | маршрут / маршрутизация |
| binding | привязка |
| priority / weight | приоритет / вес |
| circuit breaker | автоотключение |
| capability / capabilities | возможность / возможности |
| reasoning | рассуждение |
| tool | инструмент |
| MCP server | MCP-сервер |
| skill | навык |
| artifact | артефакт |
| memory | память |
| project | проект |
| knowledge base | база знаний |
| library | библиотека |
| file / upload | файл / загрузка |
| attachment | вложение |
| embedding | эмбеддинг |
| chunk | фрагмент |
| retrieval | поиск по базе (retrieval) в техническом контексте, «извлечение» не использовать |
| context window | контекстное окно |
| token | токен |
| usage | использование |
| quota | квота |
| balance | баланс |
| top-up | пополнение |
| subscription / plan / tier | подписка / тариф / уровень |
| redemption code | код активации |
| invoice / order | счёт / заказ |
| payment | платёж |
| pricing | цены / тарификация |
| billing | оплата и биллинг: «биллинг» в админке, «оплата» в пользовательских экранах |
| cost | стоимость |
| currency | валюта |
| rate limit | лимит запросов |
| user | пользователь |
| administrator / admin | администратор |
| role | роль |
| permission group | группа прав |
| account | аккаунт |
| profile | профиль |
| username | имя пользователя |
| email | эл. почта |
| password | пароль |
| session | сеанс |
| device / trusted device | устройство / доверенное устройство |
| recovery code | резервный код |
| identity provider | провайдер входа |
| sign in / sign out / register | войти / выйти / зарегистрироваться |
| announcement | объявление |
| audit log | журнал аудита |
| system event | системное событие |
| statistics | статистика |
| settings | настройки |
| share / shared link | поделиться / публичная ссылка |
| archive / archived | архивировать / в архиве |
| star / starred | в избранное / избранное |
| label | метка |
| feedback | отзыв |
| retry / regenerate | повторить / сгенерировать заново |
| branch | ветка |
| edit / delete / rename | изменить, удалить, переименовать |
| enabled / disabled | включено / отключено |
| required / optional | обязательно / необязательно |
| default | по умолчанию |
| content moderation | модерация контента |
| desktop app | приложение для компьютера |
| beta / stable | бета / стабильная |
| import / export | импорт / экспорт |
| timeout | тайм-аут |
| webhook | вебхук |
| endpoint | эндпоинт |
| API key | ключ API |
| secret key | секретный ключ |
