#!/usr/bin/env node
// Validates the ru-RU message files against the en-US originals of a DEEIX Chat checkout.
//
//   node tools/check-ru.mjs /path/to/deeix-chat [file-stem ...]
//
// Errors (exit code 1): invalid JSON, missing or extra keys, changed {placeholders},
// changed rich-text tags, Russian plurals without the one/few/many/other forms, CJK characters.
// Warnings: values still identical to English (usually brand or technical terms, review them).
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ADDON = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const REPO = path.resolve(process.argv[2] ?? ".");
const ONLY = new Set(process.argv.slice(3).map((s) => s.replace(/\.json$/, "")));
// Optional: RU_KEYS="composer,modelPicker" limits the check to those top-level sections of the namespace.
const SCOPE = process.env.RU_KEYS ? new Set(process.env.RU_KEYS.split(",").map((s) => s.trim()).filter(Boolean)) : null;
const inScope = (key) => !SCOPE || SCOPE.has(key.split(".")[0]);

const EN_DIR = path.join(REPO, "apps/web/i18n/messages/en-US");
const RU_DIR = path.join(ADDON, "files/apps/web/i18n/messages/ru-RU");

const CJK = /[㐀-鿿豈-﫿]/;
const LATIN = /[A-Za-z]{4,}/;
const CYRILLIC = /[Ѐ-ӿ]/;

function flatten(value, prefix = "", out = new Map()) {
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    for (const [key, child] of Object.entries(value)) flatten(child, prefix ? `${prefix}.${key}` : key, out);
  } else {
    out.set(prefix, value);
  }
  return out;
}

function placeholders(text) {
  const names = new Set();
  for (const match of text.matchAll(/\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*[,}]/g)) names.add(match[1]);
  return names;
}

function tags(text) {
  return new Set([...text.matchAll(/<\/?[A-Za-z][^>]*>/g)].map((m) => m[0]));
}

function sameSet(a, b) {
  return a.size === b.size && [...a].every((x) => b.has(x));
}

function diff(a, b) {
  return [...a].filter((x) => !b.has(x));
}

let errors = 0;
let warnings = 0;
const report = [];

const files = fs.readdirSync(EN_DIR).filter((f) => f.endsWith(".json")).sort();
for (const file of files) {
  const stem = file.replace(/\.json$/, "");
  if (ONLY.size && !ONLY.has(stem)) continue;

  const ruPath = path.join(RU_DIR, file);
  if (!fs.existsSync(ruPath)) {
    report.push(`ERROR ${file}: missing`);
    errors++;
    continue;
  }

  let ruRaw;
  try {
    ruRaw = JSON.parse(fs.readFileSync(ruPath, "utf8"));
  } catch (error) {
    report.push(`ERROR ${file}: invalid JSON (${error.message})`);
    errors++;
    continue;
  }

  const en = flatten(JSON.parse(fs.readFileSync(path.join(EN_DIR, file), "utf8")));
  const ru = flatten(ruRaw);
  if (Object.keys(ruRaw).length === 0) {
    report.push(`PEND  ${file}: not translated yet (${en.size} keys)`);
    continue;
  }

  const fileErrors = [];
  const fileWarnings = [];

  for (const key of en.keys()) if (inScope(key) && !ru.has(key)) fileErrors.push(`missing key: ${key}`);
  for (const key of ru.keys()) if (inScope(key) && !en.has(key)) fileErrors.push(`extra key: ${key}`);

  let same = 0;
  for (const [key, enValue] of en) {
    if (!inScope(key) || !ru.has(key)) continue;
    const ruValue = ru.get(key);
    if (typeof enValue !== "string" || typeof ruValue !== "string") {
      if (typeof enValue !== typeof ruValue) fileErrors.push(`type mismatch: ${key}`);
      continue;
    }
    if (enValue.trim() !== "" && ruValue.trim() === "") fileErrors.push(`empty value: ${key}`);

    const enPh = placeholders(enValue);
    const ruPh = placeholders(ruValue);
    if (!sameSet(enPh, ruPh)) {
      fileErrors.push(`placeholders differ in ${key}: en {${[...enPh]}} ru {${[...ruPh]}}`);
    }
    if (!sameSet(tags(enValue), tags(ruValue))) fileErrors.push(`rich-text tags differ in ${key}`);

    if (/,\s*plural\s*,/.test(enValue)) {
      for (const form of ["one", "few", "many", "other"]) {
        if (!new RegExp(`\\b${form}\\s*\\{`).test(ruValue)) fileErrors.push(`plural form "${form}" missing in ${key}`);
      }
    }
    if (/,\s*select\s*,/.test(enValue) !== /,\s*select\s*,/.test(ruValue)) fileErrors.push(`select differs in ${key}`);

    if (CJK.test(ruValue) && !CJK.test(enValue)) fileErrors.push(`CJK characters in ${key}`);

    if (ruValue === enValue && LATIN.test(enValue)) {
      same++;
      if (same <= 8) fileWarnings.push(`same as English: ${key} = ${JSON.stringify(enValue).slice(0, 60)}`);
    } else if (LATIN.test(enValue) && !CYRILLIC.test(ruValue) && ruValue !== enValue) {
      fileWarnings.push(`no Cyrillic: ${key} = ${JSON.stringify(ruValue).slice(0, 60)}`);
    }
  }
  if (same > 8) fileWarnings.push(`... and ${same - 8} more identical to English`);

  errors += fileErrors.length;
  warnings += fileWarnings.length;
  const status = fileErrors.length ? "ERROR" : fileWarnings.length ? "WARN " : "OK   ";
  report.push(`${status} ${file}: ${en.size} keys, ${fileErrors.length} errors, ${fileWarnings.length} warnings`);
  for (const line of fileErrors.slice(0, 25)) report.push(`        ! ${line}`);
  if (fileErrors.length > 25) report.push(`        ! ... and ${fileErrors.length - 25} more errors`);
  for (const line of fileWarnings.slice(0, 10)) report.push(`        ? ${line}`);
}

console.log(report.join("\n"));
console.log(`\n${errors} errors, ${warnings} warnings`);
process.exit(errors ? 1 : 0);
