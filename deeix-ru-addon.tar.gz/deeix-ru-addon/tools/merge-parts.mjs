#!/usr/bin/env node
// Merges partial translations of one namespace into its ru-RU file.
//
//   node tools/merge-parts.mjs /path/to/deeix-chat <file-stem> <parts-dir>
//
// Reads <parts-dir>/<stem>.*.json (each holds any subset of the keys, with the full path to them),
// deep-merges them and writes files/apps/web/i18n/messages/ru-RU/<stem>.json with the key order of
// the English original. Keys that exist only in the parts are appended last so the validator reports them.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ADDON = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const [repoArg, stem, partsDir] = process.argv.slice(2);
if (!repoArg || !stem || !partsDir) {
  console.error("usage: merge-parts.mjs <repo> <stem> <parts-dir>");
  process.exit(2);
}

const isObject = (v) => v !== null && typeof v === "object" && !Array.isArray(v);

function deepMerge(target, source) {
  for (const [key, value] of Object.entries(source)) {
    if (isObject(value) && isObject(target[key])) deepMerge(target[key], value);
    else target[key] = value;
  }
  return target;
}

function reorder(reference, value) {
  if (!isObject(reference) || !isObject(value)) return value;
  const out = {};
  for (const key of Object.keys(reference)) if (key in value) out[key] = reorder(reference[key], value[key]);
  for (const key of Object.keys(value)) if (!(key in out)) out[key] = value[key];
  return out;
}

const parts = fs
  .readdirSync(partsDir)
  .filter((f) => f.startsWith(`${stem}.`) && f.endsWith(".json"))
  .sort((a, b) => a.localeCompare(b, "en", { numeric: true }));
if (parts.length === 0) {
  console.error(`no parts found for ${stem} in ${partsDir}`);
  process.exit(1);
}

const merged = {};
for (const part of parts) deepMerge(merged, JSON.parse(fs.readFileSync(path.join(partsDir, part), "utf8")));

const en = JSON.parse(fs.readFileSync(path.join(repoArg, "apps/web/i18n/messages/en-US", `${stem}.json`), "utf8"));
const out = path.join(ADDON, "files/apps/web/i18n/messages/ru-RU", `${stem}.json`);
fs.writeFileSync(out, `${JSON.stringify(reorder(en, merged), null, 2)}\n`);
console.log(`${stem}: merged ${parts.length} part(s) -> ${path.relative(ADDON, out)}`);
