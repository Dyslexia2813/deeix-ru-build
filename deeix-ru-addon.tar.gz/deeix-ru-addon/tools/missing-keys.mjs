#!/usr/bin/env node
// Writes the English entries that still have no Russian translation, ready to be translated.
//
//   node tools/missing-keys.mjs <repo> <parts-dir> <out-dir> [stem ...]
//
// For each namespace, a key counts as translated when it appears in the merged ru-RU file or in any
// <parts-dir>/<stem>.*.json. The result keeps the nesting of the original, so a translated copy of it
// can be dropped into <parts-dir> as the next part. Prints "stem: missing/total".
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const ADDON = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const [repo, partsDir, outDir, ...only] = process.argv.slice(2);
if (!repo || !partsDir || !outDir) {
  console.error("usage: missing-keys.mjs <repo> <parts-dir> <out-dir> [stem ...]");
  process.exit(2);
}
const EN_DIR = path.join(repo, "apps/web/i18n/messages/en-US");
const RU_DIR = path.join(ADDON, "files/apps/web/i18n/messages/ru-RU");
const isObject = (v) => v !== null && typeof v === "object" && !Array.isArray(v);

function leaves(value, prefix = "", out = new Map()) {
  if (isObject(value)) for (const [k, v] of Object.entries(value)) leaves(v, prefix ? `${prefix}\u0000${k}` : k, out);
  else out.set(prefix, value);
  return out;
}
function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return {};
  }
}

fs.mkdirSync(outDir, { recursive: true });
for (const file of fs.readdirSync(EN_DIR).filter((f) => f.endsWith(".json")).sort()) {
  const stem = file.replace(/\.json$/, "");
  if (only.length && !only.includes(stem)) continue;
  const en = readJson(path.join(EN_DIR, file));
  const done = new Set(leaves(readJson(path.join(RU_DIR, file))).keys());
  for (const part of fs.readdirSync(partsDir).filter((f) => f.startsWith(`${stem}.`) && f.endsWith(".json"))) {
    for (const key of leaves(readJson(path.join(partsDir, part))).keys()) done.add(key);
  }
  const todo = {};
  let missing = 0;
  const all = leaves(en);
  for (const [key, value] of all) {
    if (done.has(key)) continue;
    missing++;
    let node = todo;
    const segs = key.split("\u0000");
    segs.slice(0, -1).forEach((s) => (node = node[s] ??= {}));
    node[segs[segs.length - 1]] = value;
  }
  if (missing === 0) continue;
  fs.writeFileSync(path.join(outDir, file), `${JSON.stringify(todo, null, 2)}\n`);
  console.log(`${stem}: ${missing}/${all.size}`);
}
