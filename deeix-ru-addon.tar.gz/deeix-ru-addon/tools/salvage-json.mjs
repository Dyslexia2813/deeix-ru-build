#!/usr/bin/env node
// Recovers the valid prefix of a JSON object file that was cut off mid-way (for example by an output limit).
//
//   node tools/salvage-json.mjs <file.json>
//
// Keeps every complete entry, drops the broken tail, closes the open objects and rewrites the file
// (the original is kept next to it as <file>.truncated).
import fs from "node:fs";

const file = process.argv[2];
if (!file) {
  console.error("usage: salvage-json.mjs <file.json>");
  process.exit(2);
}
const text = fs.readFileSync(file, "utf8");
try {
  JSON.parse(text);
  console.log(`${file}: already valid`);
  process.exit(0);
} catch {
  // fall through and repair
}

function closersFor(prefix) {
  const stack = [];
  let inString = false;
  let escaped = false;
  for (const ch of prefix) {
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') inString = true;
    else if (ch === "{" || ch === "[") stack.push(ch === "{" ? "}" : "]");
    else if (ch === "}" || ch === "]") stack.pop();
  }
  return inString ? null : stack.reverse().join("");
}

const lines = text.split("\n");
for (let n = lines.length - 1; n > 0; n--) {
  const prefix = lines.slice(0, n).join("\n").replace(/[,\s]+$/, "");
  const closers = closersFor(prefix);
  if (closers === null) continue;
  try {
    const value = JSON.parse(prefix + closers);
    fs.copyFileSync(file, `${file}.truncated`);
    fs.writeFileSync(file, `${JSON.stringify(value, null, 2)}\n`);
    console.log(`${file}: recovered ${n} of ${lines.length} lines`);
    process.exit(0);
  } catch {
    // keep shrinking
  }
}
console.error(`${file}: nothing recoverable`);
process.exit(1);
